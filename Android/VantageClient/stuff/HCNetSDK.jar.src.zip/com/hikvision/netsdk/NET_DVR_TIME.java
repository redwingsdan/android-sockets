/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_TIME
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int dwYear;
/*    */   
/*    */ 
/*    */   public int dwMonth;
/*    */   
/*    */   public int dwDay;
/*    */   
/*    */   public int dwHour;
/*    */   
/*    */   public int dwMinute;
/*    */   
/*    */   public int dwSecond;
/*    */   
/*    */ 
/*    */   public String ToString()
/*    */   {
/* 24 */     return this.dwYear + "/" + this.dwMonth + "/" + this.dwDay + " " + this.dwHour + ":" + this.dwMinute + ":" + this.dwSecond;
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_TIME.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */