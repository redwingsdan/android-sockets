/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_DIGITAL_CHANNEL_STATE
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   public byte[] byDigitalAudioChanTalkState = new byte[64];
/*    */   
/* 11 */   public byte[] byDigitalChanState = new byte[64];
/*    */   
/* 13 */   public byte[] byDigitalAudioChanTalkStateEx = new byte['À'];
/*    */   
/* 15 */   public byte[] byDigitalChanStateEx = new byte['À'];
/*    */   
/* 17 */   public byte[] byAnalogChanState = new byte[32];
/*    */   
/* 19 */   public byte[] byRes = new byte[32];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DIGITAL_CHANNEL_STATE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */