/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ public class NET_DVR_SEARCH_EVENT_PARAM
/*    */ {
/*    */   public short wMajorType;
/*    */   
/*    */   public short wMinorType;
/*  9 */   public NET_DVR_TIME struStartTime = new NET_DVR_TIME();
/*    */   
/* 11 */   public NET_DVR_TIME struEndTime = new NET_DVR_TIME();
/*    */   
/*    */ 
/*    */   public byte byLockType;
/*    */   
/* 16 */   public int[] wAlarmInNo = new int[''];
/*    */   
/*    */ 
/* 19 */   public int[] wMotDetChanNo = new int[64];
/*    */   
/*    */ 
/* 22 */   public int[] wBehaviorChanNo = new int[64];
/*    */   
/*    */ 
/* 25 */   public int[] dwVCAChanNo = new int[63];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SEARCH_EVENT_PARAM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */