/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_USER_INFO_V30
/*    */ {
/* 10 */   public byte[] sUserName = new byte[32];
/*    */   
/* 12 */   public byte[] sPassword = new byte[16];
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 24 */   public byte[] byLocalRight = new byte[32];
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 40 */   public byte[] byRemoteRight = new byte[32];
/*    */   
/* 42 */   public byte[] byNetPreviewRight = new byte[64];
/*    */   
/* 44 */   public byte[] byLocalPlaybackRight = new byte[64];
/*    */   
/* 46 */   public byte[] byNetPlaybackRight = new byte[64];
/*    */   
/* 48 */   public byte[] byLocalRecordRight = new byte[64];
/*    */   
/* 50 */   public byte[] byNetRecordRight = new byte[64];
/*    */   
/* 52 */   public byte[] byLocalPTZRight = new byte[64];
/*    */   
/* 54 */   public byte[] byNetPTZRight = new byte[64];
/*    */   
/* 56 */   public byte[] byLocalBackupRight = new byte[64];
/*    */   
/* 58 */   public NET_DVR_IPADDR struUserIP = new NET_DVR_IPADDR();
/*    */   
/* 60 */   public byte[] byMACAddr = new byte[6];
/*    */   
/*    */ 
/*    */ 
/*    */   public byte byPriority;
/*    */   
/*    */ 
/*    */ 
/* 68 */   public byte[] byRes = new byte[17];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_USER_INFO_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */