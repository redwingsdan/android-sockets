/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_DEVICEINFO_V30
/*    */ {
/* 12 */   public byte[] sSerialNumber = new byte[48];
/*    */   public byte byAlarmInPortNum;
/*    */   public byte byAlarmOutPortNum;
/*    */   public byte byDiskNum;
/*    */   public byte byDVRType;
/*    */   public byte byChanNum;
/*    */   public byte byStartChan;
/*    */   public byte byAudioChanNum;
/*    */   public short byIPChanNum;
/*    */   public byte byZeroChanNum;
/*    */   public short wDevType;
/*    */   public byte byStartDChan;
/*    */   public byte byHighDChanNum;
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DEVICEINFO_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */