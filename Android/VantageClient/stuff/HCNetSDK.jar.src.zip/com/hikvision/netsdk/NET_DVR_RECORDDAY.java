package com.hikvision.netsdk;

public class NET_DVR_RECORDDAY
{
  public short wAllDayRecord;
  public byte byRecordType;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_RECORDDAY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */