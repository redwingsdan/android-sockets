/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_AP_INFO_LIST
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int dwCount;
/*    */   
/*    */ 
/* 11 */   public NET_DVR_AP_INFO[] struApInfo = new NET_DVR_AP_INFO[20];
/*    */   
/*    */   public NET_DVR_AP_INFO_LIST() {
/* 14 */     for (int i = 0; i < 20; i++)
/*    */     {
/* 16 */       this.struApInfo[i] = new NET_DVR_AP_INFO();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_AP_INFO_LIST.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */