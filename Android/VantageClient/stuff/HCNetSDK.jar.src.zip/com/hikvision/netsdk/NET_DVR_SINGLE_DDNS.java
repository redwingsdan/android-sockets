/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_SINGLE_DDNS
/*    */ {
/*  8 */   public byte[] sUserName = new byte[32];
/*    */   
/* 10 */   public byte[] sPassword = new byte[16];
/*    */   
/* 12 */   public byte[] sDomainName = new byte[64];
/*    */   
/* 14 */   public byte[] sServerName = new byte[64];
/*    */   
/*    */   public int wDDNSPort;
/*    */   
/* 18 */   public byte[] byRes = new byte[16];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SINGLE_DDNS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */