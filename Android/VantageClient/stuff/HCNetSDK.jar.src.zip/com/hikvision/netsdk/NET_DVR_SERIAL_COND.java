package com.hikvision.netsdk;

public class NET_DVR_SERIAL_COND {}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SERIAL_COND.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */