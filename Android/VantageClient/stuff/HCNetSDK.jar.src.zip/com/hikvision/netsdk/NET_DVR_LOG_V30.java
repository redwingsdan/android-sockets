/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_LOG_V30
/*    */ {
/* 10 */   public NET_DVR_TIME strLogTime = new NET_DVR_TIME();
/*    */   public int dwMajorType;
/*    */   public int dwMinorType;
/* 13 */   public byte[] sPanelUser = new byte[16];
/* 14 */   public byte[] sNetUser = new byte[16];
/* 15 */   public NET_DVR_IPADDR struRemoteHostAddr = new NET_DVR_IPADDR();
/*    */   public int dwParaType;
/*    */   public int dwChannel;
/*    */   public int dwDiskNumber;
/*    */   public int dwAlarmInPort;
/*    */   public int dwAlarmOutPort;
/*    */   public int dwInfoLen;
/* 22 */   public byte[] sInfo = new byte['⹀'];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_LOG_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */