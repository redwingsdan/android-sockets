/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_VICOLOR
/*    */ {
/*  9 */   public NET_DVR_COLOR[] struColor = new NET_DVR_COLOR[8];
/*    */   
/* 11 */   public NET_DVR_SCHEDTIME[] struHandleTime = new NET_DVR_SCHEDTIME[8];
/*    */   
/*    */   public NET_DVR_VICOLOR()
/*    */   {
/* 15 */     for (int i = 0; i < 8; i++)
/*    */     {
/* 17 */       this.struColor[i] = new NET_DVR_COLOR();
/* 18 */       this.struHandleTime[i] = new NET_DVR_SCHEDTIME();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_VICOLOR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */