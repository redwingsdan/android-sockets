/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ public class NET_DVR_EZVIZ_USER_LOGIN_INFO
/*    */ {
/*  6 */   public byte[] sEzvizServerAddress = new byte[''];
/*    */   
/*    */   public int wPort;
/*    */   
/* 10 */   public byte[] byRes1 = new byte[2];
/*    */   
/* 12 */   public byte[] sClassSession = new byte[64];
/*    */   
/* 14 */   public byte[] sDeviceID = new byte[32];
/*    */   
/* 16 */   public byte[] byRes2 = new byte[''];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_EZVIZ_USER_LOGIN_INFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */