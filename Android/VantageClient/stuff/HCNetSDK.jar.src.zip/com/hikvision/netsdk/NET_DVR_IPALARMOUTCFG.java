/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_IPALARMOUTCFG
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   public NET_DVR_IPALARMOUTINFO[] struIPAlarmOutInfo = new NET_DVR_IPALARMOUTINFO[64];
/*    */   
/*    */   public NET_DVR_IPALARMOUTCFG() {
/* 12 */     for (int i = 0; i < 64; i++)
/*    */     {
/* 14 */       this.struIPAlarmOutInfo[i] = new NET_DVR_IPALARMOUTINFO();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_IPALARMOUTCFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */