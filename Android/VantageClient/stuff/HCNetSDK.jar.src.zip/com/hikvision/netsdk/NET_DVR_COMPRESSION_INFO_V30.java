/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_COMPRESSION_INFO_V30
/*    */ {
/*    */   public byte byStreamType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte byResolution;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte byBitrateType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte byPicQuality;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int dwVideoBitrate;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public int dwVideoFrameRate;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public short wIntervalFrameI;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte byIntervalBPFrame;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte byENumber;
/*    */   
/*    */ 
/*    */ 
/*    */   public byte byVideoEncType;
/*    */   
/*    */ 
/*    */ 
/*    */   public byte byAudioEncType;
/*    */   
/*    */ 
/*    */ 
/* 61 */   public byte[] byRes = new byte[10];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_COMPRESSION_INFO_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */