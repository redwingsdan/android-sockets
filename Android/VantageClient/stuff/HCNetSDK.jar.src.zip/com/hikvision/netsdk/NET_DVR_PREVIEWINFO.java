package com.hikvision.netsdk;

public class NET_DVR_PREVIEWINFO
{
  public int lChannel;
  public int dwStreamType;
  public int dwLinkMode;
  public int bBlocked;
  public int bPassbackRecord;
  public byte byPreviewMode;
  public byte byProtoType;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PREVIEWINFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */