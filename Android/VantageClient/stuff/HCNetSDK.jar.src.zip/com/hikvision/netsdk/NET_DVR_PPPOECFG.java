/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_PPPOECFG
/*    */ {
/*    */   public int dwPPPOE;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 14 */   public byte[] sPPPoEUser = new byte[32];
/*    */   
/*    */ 
/*    */ 
/* 18 */   public byte[] sPPPoEPassword = new byte[16];
/*    */   
/* 20 */   public NET_DVR_IPADDR struPPPoEIP = new NET_DVR_IPADDR();
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PPPOECFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */