/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_RECORD_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int dwRecord;
/*    */   
/*    */ 
/* 11 */   public NET_DVR_RECORDDAY[] struRecAllDay = new NET_DVR_RECORDDAY[7];
/*    */   
/* 13 */   public NET_DVR_RECORDSCHED[][] struRecordSched = new NET_DVR_RECORDSCHED[7][8];
/*    */   
/*    */   public int dwRecordTime;
/*    */   
/*    */   public int dwPreRecordTime;
/*    */   
/*    */   public int dwRecorderDuration;
/*    */   
/*    */   public byte byRedundancyRec;
/*    */   
/*    */   public byte byAudioRec;
/*    */   
/*    */   public byte byStreamType;
/*    */   
/*    */   public byte byPassbackRecord;
/*    */   
/*    */   public short wLockDuration;
/*    */   
/*    */   public byte byRecordBackup;
/*    */   
/*    */   public byte bySVCLevel;
/*    */   
/* 35 */   public byte[] byReserve = new byte[4];
/*    */   
/*    */   public NET_DVR_RECORD_V30() {
/* 38 */     for (int i = 0; i < 7; i++) {
/* 39 */       this.struRecAllDay[i] = new NET_DVR_RECORDDAY();
/* 40 */       for (int j = 0; j < 8; j++)
/*    */       {
/* 42 */         this.struRecordSched[i][j] = new NET_DVR_RECORDSCHED();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_RECORD_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */