/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ABILITY_LIST
/*    */ {
/*    */   public int dwAbilityType;
/*    */   
/*    */ 
/* 11 */   public byte[] byRes = new byte[32];
/*    */   
/*    */   public int dwNodeNum;
/*    */   
/* 15 */   public NET_DVR_DESC_NODE[] struDescNode = new NET_DVR_DESC_NODE['Ā'];
/*    */   
/*    */   public NET_DVR_ABILITY_LIST() {
/* 18 */     for (int i = 0; i < 256; i++) {
/* 19 */       this.struDescNode[i] = new NET_DVR_DESC_NODE();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ABILITY_LIST.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */