/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ALARMOUTCFG_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   public byte[] sAlarmOutName = new byte[32];
/*    */   
/*    */   public int dwAlarmOutDelay;
/*    */   
/* 13 */   public NET_DVR_SCHEDTIME[][] struAlarmOutTime = new NET_DVR_SCHEDTIME[7][8];
/*    */   
/*    */   public NET_DVR_ALARMOUTCFG_V30()
/*    */   {
/* 17 */     for (int i = 0; i < 7; i++)
/*    */     {
/* 19 */       for (int j = 0; j < 8; j++)
/*    */       {
/* 21 */         this.struAlarmOutTime[i][j] = new NET_DVR_SCHEDTIME();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMOUTCFG_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */