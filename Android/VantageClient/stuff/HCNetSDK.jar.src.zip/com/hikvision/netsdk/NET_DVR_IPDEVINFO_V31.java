/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_IPDEVINFO_V31
/*    */ {
/*    */   public byte byEnable;
/*    */   
/*    */ 
/*    */ 
/*    */   public byte byProType;
/*    */   
/*    */ 
/*    */ 
/* 16 */   public byte[] sUserName = new byte[32];
/*    */   
/*    */ 
/*    */ 
/* 20 */   public byte[] sPassword = new byte[16];
/*    */   
/*    */ 
/*    */ 
/* 24 */   public byte[] byDomain = new byte[64];
/*    */   
/* 26 */   public NET_DVR_IPADDR struIP = new NET_DVR_IPADDR();
/*    */   public int wDVRPort;
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_IPDEVINFO_V31.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */