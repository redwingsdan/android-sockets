/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_DDNSPARA_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public byte byEnableDDNS;
/*    */   
/*    */   public byte byHostIndex;
/*    */   
/* 12 */   public byte[] byRes1 = new byte[2];
/*    */   
/* 14 */   public NET_DVR_SINGLE_DDNS[] struDDNS = new NET_DVR_SINGLE_DDNS[10];
/*    */   
/* 16 */   public byte[] byRes2 = new byte[16];
/*    */   
/*    */   public NET_DVR_DDNSPARA_V30() {
/* 19 */     for (int i = 0; i < 10; i++)
/*    */     {
/* 21 */       this.struDDNS[i] = new NET_DVR_SINGLE_DDNS();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DDNSPARA_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */