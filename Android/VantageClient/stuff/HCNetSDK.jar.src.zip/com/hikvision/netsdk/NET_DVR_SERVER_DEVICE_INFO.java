/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_SERVER_DEVICE_INFO
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int dwDeviceNum;
/*  7 */   public NET_DVR_SERVER_DEVICE_CFG[] struDeviceCfg = new NET_DVR_SERVER_DEVICE_CFG[16];
/*    */   
/*  9 */   public byte[] byRes = new byte['È'];
/*    */   
/*    */   public NET_DVR_SERVER_DEVICE_INFO() {
/* 12 */     for (int i = 0; i < 16; i++)
/*    */     {
/* 14 */       this.struDeviceCfg[i] = new NET_DVR_SERVER_DEVICE_CFG();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SERVER_DEVICE_INFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */