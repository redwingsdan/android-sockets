/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ 
/*   */ public class NET_DVR_PRESET_NAME
/*   */ {
/*   */   public int wPresetNum;
/*   */   
/* 9 */   public byte[] byName = new byte[32];
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PRESET_NAME.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */