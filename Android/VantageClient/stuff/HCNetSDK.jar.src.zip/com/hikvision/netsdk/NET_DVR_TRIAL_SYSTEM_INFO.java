/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_TRIAL_SYSTEM_INFO
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public byte byVideoInTypeNum;
/*  7 */   public NET_DVR_VIDEOIN_TYPE_INFO[] struVideoIn = new NET_DVR_VIDEOIN_TYPE_INFO[10];
/*    */   
/*    */   public NET_DVR_TRIAL_SYSTEM_INFO() {
/* 10 */     for (int i = 0; i < 10; i++)
/*    */     {
/* 12 */       this.struVideoIn[i] = new NET_DVR_VIDEOIN_TYPE_INFO();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_TRIAL_SYSTEM_INFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */