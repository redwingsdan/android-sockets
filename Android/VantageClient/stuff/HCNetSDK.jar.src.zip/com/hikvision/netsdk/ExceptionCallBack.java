package com.hikvision.netsdk;

public abstract interface ExceptionCallBack
{
  public abstract void fExceptionCallBack(int paramInt1, int paramInt2, int paramInt3);
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\ExceptionCallBack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */