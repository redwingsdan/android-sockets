package com.hikvision.netsdk;

public class NET_DVR_COLOR
{
  public byte byBrightness;
  public byte byContrast;
  public byte bySaturation;
  public byte byHue;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_COLOR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */