package com.hikvision.netsdk;

public class NET_DVR_KEY_CODE
{
  public static final int KEY_CODE_MENU = 12;
  public static final int KEY_CODE_ENTER = 13;
  public static final int KEY_CODE_CANCEL = 14;
  public static final int KEY_CODE_UP = 15;
  public static final int KEY_CODE_DOWN = 16;
  public static final int KEY_CODE_LEFT = 17;
  public static final int KEY_CODE_RIGHT = 18;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_KEY_CODE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */