/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ public class NET_DVR_PRESET_NAME_ARRAY
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  7 */   public NET_DVR_PRESET_NAME[] struPresetName = new NET_DVR_PRESET_NAME['Ā'];
/*    */   
/*    */   public NET_DVR_PRESET_NAME_ARRAY()
/*    */   {
/* 11 */     for (int i = 0; i < 256; i++)
/*    */     {
/* 13 */       this.struPresetName[i] = new NET_DVR_PRESET_NAME();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PRESET_NAME_ARRAY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */