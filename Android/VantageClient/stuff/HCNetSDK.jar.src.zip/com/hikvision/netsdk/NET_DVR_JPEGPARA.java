package com.hikvision.netsdk;

public class NET_DVR_JPEGPARA
{
  public short wPicSize;
  public short wPicQuality;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_JPEGPARA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */