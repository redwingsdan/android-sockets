/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_HIDEALARM_V30
/*    */ {
/*    */   public int dwEnableHideAlarm;
/*    */   
/*    */ 
/*    */   public short wHideAlarmAreaTopLeftX;
/*    */   
/*    */ 
/*    */   public short wHideAlarmAreaTopLeftY;
/*    */   
/*    */   public short wHideAlarmAreaWidth;
/*    */   
/*    */   public short wHideAlarmAreaHeight;
/*    */   
/* 19 */   public NET_DVR_HANDLEEXCEPTION_V30 struHideAlarmHandleType = new NET_DVR_HANDLEEXCEPTION_V30();
/*    */   
/* 21 */   public NET_DVR_SCHEDTIME[][] struAlarmTime = new NET_DVR_SCHEDTIME[7][8];
/*    */   
/*    */   public NET_DVR_HIDEALARM_V30()
/*    */   {
/* 25 */     for (int i = 0; i < 7; i++)
/*    */     {
/* 27 */       for (int j = 0; j < 8; j++)
/*    */       {
/* 29 */         this.struAlarmTime[i][j] = new NET_DVR_SCHEDTIME();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_HIDEALARM_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */