/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_IPPARACFG_V31
/*    */   extends NET_DVR_CONFIG
/*    */ {
/* 12 */   public NET_DVR_IPDEVINFO_V31[] struIPDevInfo = new NET_DVR_IPDEVINFO_V31[32];
/*    */   
/*    */ 
/*    */ 
/* 16 */   public byte[] byAnalogChanEnable = new byte[32];
/*    */   
/*    */ 
/*    */ 
/* 20 */   public NET_DVR_IPCHANINFO[] struIPChanInfo = new NET_DVR_IPCHANINFO[32];
/*    */   
/*    */   public NET_DVR_IPPARACFG_V31() {
/* 23 */     for (int i = 0; i < 32; i++) {
/* 24 */       this.struIPDevInfo[i] = new NET_DVR_IPDEVINFO_V31();
/*    */     }
/*    */     
/* 27 */     for (int i = 0; i < 32; i++) {
/* 28 */       this.struIPChanInfo[i] = new NET_DVR_IPCHANINFO();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_IPPARACFG_V31.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */