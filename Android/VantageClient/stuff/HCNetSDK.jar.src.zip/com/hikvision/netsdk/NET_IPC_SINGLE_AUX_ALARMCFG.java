/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_IPC_SINGLE_AUX_ALARMCFG
/*    */ {
/*    */   public byte byAlarmType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/* 16 */   public NET_IPC_PIR_ALARMCFG struPIRAlarm = new NET_IPC_PIR_ALARMCFG();
/*    */   
/* 18 */   public NET_IPC_SINGLE_WIRELESS_ALARMCFG[] struWirelessAlarm = new NET_IPC_SINGLE_WIRELESS_ALARMCFG[8];
/*    */   
/* 20 */   public NET_IPC_CALLHELP_ALARMCFG struCallHelpAlarm = new NET_IPC_CALLHELP_ALARMCFG();
/*    */   
/*    */   public NET_IPC_SINGLE_AUX_ALARMCFG()
/*    */   {
/* 24 */     for (int i = 0; i < 8; i++)
/*    */     {
/* 26 */       this.struWirelessAlarm[i] = new NET_IPC_SINGLE_WIRELESS_ALARMCFG();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_IPC_SINGLE_AUX_ALARMCFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */