/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public class NET_DVR_RECORDSCHED
/*   */ {
/* 9 */   public NET_DVR_SCHEDTIME struRecordTime = new NET_DVR_SCHEDTIME();
/*   */   public byte byRecordType;
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_RECORDSCHED.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */