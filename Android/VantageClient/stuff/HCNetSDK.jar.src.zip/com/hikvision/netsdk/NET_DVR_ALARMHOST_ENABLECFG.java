/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_ALARMHOST_ENABLECFG extends NET_DVR_CONFIG
/*    */ {
/*  5 */   public byte[] byAudioOutEnable = new byte[32];
/*    */   
/*  7 */   public byte[] byElectroLockEnable = new byte[32];
/*    */   
/*  9 */   public byte[] byMobileGateEnable = new byte[32];
/*    */   
/* 11 */   public byte[] bySirenEnable = new byte[8];
/*    */   
/*    */   public byte bySerialPurpose;
/*    */   
/* 15 */   public byte[] byRes = new byte[63];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMHOST_ENABLECFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */