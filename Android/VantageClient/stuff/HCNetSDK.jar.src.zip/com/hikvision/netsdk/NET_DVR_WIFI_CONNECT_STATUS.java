package com.hikvision.netsdk;

public class NET_DVR_WIFI_CONNECT_STATUS
  extends NET_DVR_CONFIG
{
  public byte byCurStatus;
  public int dwErrorCode;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_WIFI_CONNECT_STATUS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */