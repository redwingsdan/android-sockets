package com.hikvision.netsdk;

public abstract interface AlarmCallBack_V30
{
  public abstract void fMSGCallBack(int paramInt, NET_DVR_ALARMER paramNET_DVR_ALARMER, NET_DVR_BASE_ALARM paramNET_DVR_BASE_ALARM);
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\AlarmCallBack_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */