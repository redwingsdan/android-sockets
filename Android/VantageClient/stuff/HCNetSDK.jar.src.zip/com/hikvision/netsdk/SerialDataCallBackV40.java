package com.hikvision.netsdk;

public abstract interface SerialDataCallBackV40
{
  public abstract void fSerialDataCallBackV40(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\SerialDataCallBackV40.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */