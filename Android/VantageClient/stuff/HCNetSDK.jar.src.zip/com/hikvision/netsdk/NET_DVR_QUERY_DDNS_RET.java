/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public class NET_DVR_QUERY_DDNS_RET
/*   */   extends NET_DVR_ADDR_QUERY_RET
/*   */ {
/* 9 */   public byte[] szDevIP = new byte[48];
/*   */   public int wCmdPort;
/*   */   public int wHttpPort;
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_QUERY_DDNS_RET.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */