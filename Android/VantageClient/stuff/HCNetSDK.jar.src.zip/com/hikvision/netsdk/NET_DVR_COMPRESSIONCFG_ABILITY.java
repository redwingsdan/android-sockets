/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_COMPRESSIONCFG_ABILITY
/*    */ {
/*    */   public int dwSize;
/*    */   
/*    */ 
/*    */   public int dwAbilityNum;
/*    */   
/*    */ 
/* 13 */   public NET_DVR_ABILITY_LIST[] struAbilityNode = new NET_DVR_ABILITY_LIST[12];
/*    */   
/*    */   public NET_DVR_COMPRESSIONCFG_ABILITY() {
/* 16 */     for (int i = 0; i < 12; i++) {
/* 17 */       this.struAbilityNode[i] = new NET_DVR_ABILITY_LIST();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_COMPRESSIONCFG_ABILITY.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */