/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_QUERY_DDNS_COND
/*    */   extends NET_DVR_ADDR_QUERY_COND
/*    */ {
/*  9 */   public byte[] szResolveSvrAddr = new byte[64];
/*    */   
/* 11 */   public byte[] szDevNickName = new byte[64];
/*    */   
/* 13 */   public byte[] szDevSerial = new byte[48];
/*    */   
/* 15 */   public byte[] szClientVersion = new byte[64];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_QUERY_DDNS_COND.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */