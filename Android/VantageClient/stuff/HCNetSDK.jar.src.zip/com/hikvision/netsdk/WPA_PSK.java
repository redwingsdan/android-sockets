/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WPA_PSK
/*    */ {
/*    */   public int dwKeyLength;
/*    */   
/*    */ 
/* 11 */   public byte[] sKeyInfo = new byte[63];
/*    */   public byte byEncryptType;
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\WPA_PSK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */