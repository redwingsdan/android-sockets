package com.hikvision.netsdk;

public class NET_DVR_VIDEOIN_TYPE_INFO
{
  public int wInType;
  public int wInNum;
  public int wStartNo;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_VIDEOIN_TYPE_INFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */