/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_USER_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/* 10 */   public NET_DVR_USER_INFO_V30[] struUser = new NET_DVR_USER_INFO_V30[32];
/*    */   
/*    */   public NET_DVR_USER_V30() {
/* 13 */     for (int i = 0; i < 32; i++)
/*    */     {
/* 15 */       this.struUser[i] = new NET_DVR_USER_INFO_V30();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_USER_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */