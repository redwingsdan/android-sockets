/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EAP_TLS
/*    */ {
/*    */   public byte byEapolVersion;
/*    */   
/*    */ 
/* 11 */   public byte[] byIdentity = new byte[32];
/*    */   
/* 13 */   public byte[] byPrivateKeyPswd = new byte[32];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\EAP_TLS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */