/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ public class NET_DVR_PUBLIC_SUB_SYSTEM
/*   */ {
/*   */   public int dwJointSubSystem;
/* 7 */   public byte[] byRes = new byte[16];
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PUBLIC_SUB_SYSTEM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */