package com.hikvision.netsdk;

public class NET_DVR_SHELTER
{
  public short wHideAreaTopLeftX;
  public short wHideAreaTopLeftY;
  public short wHideAreaWidth;
  public short wHideAreaHeight;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SHELTER.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */