/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_EXCEPTION_V40
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int dwMaxGroupNum;
/*    */   
/*    */ 
/*    */ 
/* 13 */   public NET_DVR_HANDLEEXCEPTION_V41[] struExceptionHandle = new NET_DVR_HANDLEEXCEPTION_V41[32];
/*    */   
/* 15 */   public byte[] byRes = new byte[''];
/*    */   
/*    */   public NET_DVR_EXCEPTION_V40() {
/* 18 */     for (int i = 0; i < 32; i++) {
/* 19 */       this.struExceptionHandle[i] = new NET_DVR_HANDLEEXCEPTION_V41();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_EXCEPTION_V40.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */