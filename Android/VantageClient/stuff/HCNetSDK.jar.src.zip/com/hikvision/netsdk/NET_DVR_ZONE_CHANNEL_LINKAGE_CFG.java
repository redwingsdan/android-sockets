/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_ZONE_CHANNEL_LINKAGE_CFG extends NET_DVR_CONFIG
/*    */ {
/*  5 */   public NET_DVR_SINGLE_CHANNEL_LINKAGE_CFG[] struLinkChannels = new NET_DVR_SINGLE_CHANNEL_LINKAGE_CFG[4];
/*    */   
/*  7 */   public byte[] byRes = new byte['Ā'];
/*    */   
/*    */   public NET_DVR_ZONE_CHANNEL_LINKAGE_CFG() {
/* 10 */     for (int i = 0; i < 4; i++)
/*    */     {
/* 12 */       this.struLinkChannels[i] = new NET_DVR_SINGLE_CHANNEL_LINKAGE_CFG();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ZONE_CHANNEL_LINKAGE_CFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */