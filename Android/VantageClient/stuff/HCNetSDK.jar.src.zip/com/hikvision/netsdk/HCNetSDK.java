/*      */ package com.hikvision.netsdk;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class HCNetSDK
/*      */ {
/*   11 */   static HCNetSDK netSdk = null;
/*      */   public static final int MAX_ALARMIN_V30 = 160;
/*      */   public static final int MAX_AUDIO_V30 = 2;
/*      */   public static final int MAX_LINK = 6;
/*      */   
/*      */   public static synchronized HCNetSDK getInstance()
/*      */   {
/*   18 */     if (netSdk == null) {
/*   19 */       netSdk = new HCNetSDK();
/*      */     }
/*   21 */     return netSdk;
/*      */   }
/*      */   
/*      */ 
/*      */   static
/*      */   {
/*   27 */     System.loadLibrary("opensslwrap");
/*   28 */     System.loadLibrary("HCCore");
/*   29 */     System.loadLibrary("HCCoreDevCfg");
/*      */     try
/*      */     {
/*   32 */       System.loadLibrary("HCPreview");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError1) {}
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*   39 */       System.loadLibrary("HCPlayBack");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError2) {}
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*   46 */       System.loadLibrary("HCGeneralCfgMgr");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError3) {}
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*   53 */       System.loadLibrary("HCVoiceTalk");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError4) {}
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*   60 */       System.loadLibrary("HCIndustry");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError5) {}
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*   67 */       System.loadLibrary("HCDisplay");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError6) {}
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*   74 */       System.loadLibrary("HCAlarm");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError7) {}
/*      */     
/*      */ 
/*      */     try
/*      */     {
/*   81 */       System.loadLibrary("SystemTransform");
/*      */     }
/*      */     catch (UnsatisfiedLinkError localUnsatisfiedLinkError8) {}
/*      */     
/*      */ 
/*   86 */     System.loadLibrary("hcnetsdk");
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */   public static final int MAX_WIRELESS_ALARM_NUM = 8;
/*      */   
/*      */ 
/*      */   public static final int MAX_AUX_ALARM_NUM = 8;
/*      */   
/*      */ 
/*      */   public static final int MAX_DAYS = 7;
/*      */   
/*      */ 
/*      */   public static final int MAX_TIMESEGMENT_V30 = 8;
/*      */   
/*      */ 
/*      */   public static final int SERIALNO_LEN = 48;
/*      */   
/*      */ 
/*      */   public static final int NAME_LEN = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_EXCEPTIONNUM_V30 = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMOUT_V40 = 4128;
/*      */   
/*      */ 
/*      */   public static final int PASSWD_LEN = 16;
/*      */   
/*      */ 
/*      */   public static final int MACADDR_LEN = 6;
/*      */   
/*      */ 
/*      */   public static final int MAX_ETHERNET = 2;
/*      */   
/*      */ 
/*      */   public static final int MAX_DOMAIN_NAME = 64;
/*      */   
/*      */ 
/*      */   public static final int MAX_ANALOG_CHANNUM = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_IP_DEVICE = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_IP_CHANNEL = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_ANALOG_ALARMOUT = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_IP_ALARMOUT = 64;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMOUT_V30 = 96;
/*      */   
/*      */ 
/*      */   public static final int MAX_IP_DEVICE_V40 = 64;
/*      */   
/*      */ 
/*      */   public static final int MAX_CHANNUM = 16;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMIN = 16;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMOUT = 4;
/*      */   
/*      */ 
/*      */   public static final int MAX_DISKNUM = 16;
/*      */   
/*      */ 
/*      */   public static final int MAX_ABILITYTYPE_NUM = 12;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMHOST_ALARMIN_NUM = 512;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMHOSTKEYBOARD = 64;
/*      */   
/*      */ 
/*      */   public static final int MAX_KEYBOARD_USER_NUM = 256;
/*      */   
/*      */ 
/*      */   public static final int MAX_TIMESEGMENT = 4;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMHOST_ALARMOUT_NUM = 512;
/*      */   
/*      */ 
/*      */   public static final int MAX_ALARMHOST_SUBSYSTEM = 32;
/*      */   
/*      */ 
/*      */   public static final int ALARMHOST_MAX_SIREN_NUM = 8;
/*      */   
/*      */ 
/*      */   public static final int ALARMHOST_MAX_AUDIOOUT_NUM = 32;
/*      */   
/*      */ 
/*      */   public static final int ALARMHOST_MAX_ELECTROLOCK_NUM = 32;
/*      */   
/*      */ 
/*      */   public static final int ALARMHOST_MAX_MOBILEGATE_NUM = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_ZONE_LINKAGE_CHAN_NUM = 4;
/*      */   
/*      */ 
/*      */   public static final int DESC_LEN = 16;
/*      */   
/*      */ 
/*      */   public static final int DESC_LEN_32 = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_NODE_NUM = 256;
/*      */   
/*      */ 
/*      */   public static final int MAX_CHANNUM_V30 = 64;
/*      */   
/*      */ 
/*      */   public static final int MAX_DISKNUM_V30 = 33;
/*      */   
/*      */ 
/*      */   public static final int MAX_PRESET_V30 = 256;
/*      */   
/*      */ 
/*      */   public static final int MAX_CRUISE_V30 = 256;
/*      */   
/*      */ 
/*      */   public static final int MAX_TRACK_V30 = 256;
/*      */   
/*      */ 
/*      */   public static final int MAX_SHELTERNUM = 4;
/*      */   
/*      */ 
/*      */   public static final int PTZ_PROTOCOL_NUM = 200;
/*      */   
/*      */ 
/*      */   public static final int WIFI_MAX_AP_COUNT = 20;
/*      */   
/*      */ 
/*      */   public static final int IW_ESSID_MAX_SIZE = 32;
/*      */   
/*      */ 
/*      */   public static final int WIFI_WPA_PSK_MAX_KEY_LENGTH = 63;
/*      */   
/*      */ 
/*      */   public static final int WIFI_WEP_MAX_KEY_COUNT = 4;
/*      */   
/*      */ 
/*      */   public static final int WIFI_WEP_MAX_KEY_LENGTH = 33;
/*      */   
/*      */ 
/*      */   public static final int MAX_USERNUM_V30 = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_RIGHT = 32;
/*      */   
/*      */ 
/*      */   public static final int MAX_DDNS_NUMS = 10;
/*      */   
/*      */ 
/*      */   public static final int JUDGE_MAX_VIDEOOUT_NUM = 9;
/*      */   
/*      */ 
/*      */   public static final int MAX_VIDEOIN_TYPE_NUM = 10;
/*      */   
/*      */ 
/*      */   public static final int MICROPHONE_NUM = 16;
/*      */   
/*      */ 
/*      */   public static final int FAN_NUM = 8;
/*      */   
/*      */ 
/*      */   public static final int MAIN_BOARD = 8;
/*      */   
/*      */ 
/*      */   public static final int FPGA_NUM = 8;
/*      */   
/*      */ 
/*      */   public static final int MAX_PRESET_NUM = 256;
/*      */   
/*      */ 
/*      */   public static final int MAX_SERVER_DEVICE_NUMBER = 16;
/*      */   
/*      */ 
/*      */   public static final int CALLER_SERIAL_NUMBER = 11;
/*      */   
/*      */ 
/*      */   public static final int SDK_MAX_IP_LEN = 48;
/*      */   
/*      */ 
/*      */   public static final int CLIENT_VERSION_LEN = 64;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_EXCHANGE = 32768;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_AUDIOEXCHANGE = 32769;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_ALARM = 32770;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_PREVIEW = 32771;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_SERIAL = 32772;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_RECONNECT = 32773;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_ALARMRECONNECT = 32774;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_SERIALRECONNECT = 32775;
/*      */   
/*      */ 
/*      */   public static final int SERIAL_RECONNECTSUCCESS = 32776;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_PLAYBACK = 32784;
/*      */   
/*      */ 
/*      */   public static final int EXCEPTION_DISKFMT = 32785;
/*      */   
/*      */ 
/*      */   public static final int PREVIEW_RECONNECTSUCCESS = 32789;
/*      */   
/*      */ 
/*      */   public static final int ALARM_RECONNECTSUCCESS = 32790;
/*      */   
/*      */ 
/*      */   public static final int RESUME_EXCHANGE = 32791;
/*      */   
/*      */ 
/*      */   public static final int NET_DVR_SYSHEAD = 1;
/*      */   
/*      */ 
/*      */   public static final int NET_DVR_STREAMDATA = 2;
/*      */   
/*      */ 
/*      */   public static final int NET_DVR_AUDIOSTREAMDATA = 3;
/*      */   
/*      */ 
/*      */   public static final int NET_DVR_STD_VIDEODATA = 4;
/*      */   
/*      */ 
/*      */   public static final int NET_DVR_STD_AUDIODATA = 5;
/*      */   
/*      */ 
/*      */   public static final int NET_DVR_GET_DEVICECFG = 100;
/*      */   
/*      */ 
/*      */   public static final int NET_DVR_SET_DEVICECFG = 101;
/*      */   
/*      */   public static final int NET_DVR_GET_NETCFG_V30 = 1000;
/*      */   
/*      */   public static final int NET_DVR_SET_NETCFG_V30 = 1001;
/*      */   
/*      */   public static final int NET_DVR_GET_PICCFG_V30 = 1002;
/*      */   
/*      */   public static final int NET_DVR_SET_PICCFG_V30 = 1003;
/*      */   
/*      */   public static final int NET_DVR_GET_COMPRESSCFG_V30 = 1040;
/*      */   
/*      */   public static final int NET_DVR_SET_COMPRESSCFG_V30 = 1041;
/*      */   
/*      */   public static final int NET_DVR_GET_IPALARMOUTCFG = 1052;
/*      */   
/*      */   public static final int NET_DVR_GET_IPPARACFG_V31 = 1060;
/*      */   
/*      */   public static final int NET_DVR_SET_IPPARACFG_V31 = 1061;
/*      */   
/*      */   public static final int NET_DVR_GET_COMPRESSCFG_AUD = 1058;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMINCFG_V30 = 1024;
/*      */   
/*      */   public static final int NET_DVR_SET_ALARMINCFG_V30 = 1025;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMOUTCFG_V30 = 1026;
/*      */   
/*      */   public static final int NET_DVR_SET_ALARMOUTCFG_V30 = 1027;
/*      */   
/*      */   public static final int NET_DVR_GET_NTPCFG = 224;
/*      */   
/*      */   public static final int NET_DVR_SET_NTPCFG = 225;
/*      */   
/*      */   public static final int NET_DVR_GET_IPPARACFG_V40 = 1062;
/*      */   
/*      */   public static final int NET_DVR_SET_IPPARACFG_V40 = 1063;
/*      */   
/*      */   public static final int NET_DVR_GET_DECODERCFG_V30 = 1042;
/*      */   
/*      */   public static final int NET_DVR_SET_DECODERCFG_V30 = 1043;
/*      */   
/*      */   public static final int NET_IPC_GET_AUX_ALARMCFG = 3209;
/*      */   
/*      */   public static final int NET_IPC_SET_AUX_ALARMCFG = 3210;
/*      */   
/*      */   public static final int NET_DVR_GET_RECORDCFG_V30 = 1004;
/*      */   
/*      */   public static final int NET_DVR_SET_RECORDCFG_V30 = 1005;
/*      */   
/*      */   public static final int NET_DVR_GET_ZEROCHANCFG = 1102;
/*      */   
/*      */   public static final int NET_DVR_SET_ZEROCHANCFG = 1103;
/*      */   
/*      */   public static final int NET_DVR_GET_DEVICECFG_V40 = 1100;
/*      */   
/*      */   public static final int NET_DVR_GET_EXCEPTIONCFG_V40 = 6177;
/*      */   
/*      */   public static final int NET_DVR_GET_AP_INFO_LIST = 305;
/*      */   
/*      */   public static final int NET_DVR_SET_WIFI_CFG = 306;
/*      */   
/*      */   public static final int NET_DVR_GET_WIFI_CFG = 307;
/*      */   
/*      */   public static final int NET_DVR_GET_WIFI_STATUS = 310;
/*      */   
/*      */   public static final int NET_DVR_GET_TIMECFG = 118;
/*      */   
/*      */   public static final int NET_DVR_SET_TIMECFG = 119;
/*      */   
/*      */   public static final int NET_DVR_GET_USERCFG_V30 = 1006;
/*      */   
/*      */   public static final int NET_DVR_SET_USERCFG_V30 = 1007;
/*      */   
/*      */   public static final int NET_DVR_GET_DDNSCFG_V30 = 1010;
/*      */   
/*      */   public static final int NET_DVR_SET_DDNSCFG_V30 = 1011;
/*      */   
/*      */   public static final int NET_DVR_GET_DIGITAL_CHANNEL_STATE = 6126;
/*      */   
/*      */   public static final int NET_DVR_GET_SHOWSTRING_V30 = 1030;
/*      */   
/*      */   public static final int NET_DVR_SET_SHOWSTRING_V30 = 1031;
/*      */   
/*      */   public static final int NET_DVR_GET_AUDIO_ACTIVATION_CFG = 6326;
/*      */   
/*      */   public static final int NET_DVR_SET_AUDIO_ACTIVATION_CFG = 6327;
/*      */   
/*      */   public static final int NET_DVR_GET_TRIAL_SYSTEM_CFG = 6334;
/*      */   
/*      */   public static final int NET_DVR_GET_TRIAL_MICROPHONE_STATUS = 6336;
/*      */   
/*      */   public static final int NET_DVR_GET_TRIAL_HOST_STATUS = 6338;
/*      */   
/*      */   public static final int NET_DVR_GET_PRESET_NAME = 3383;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMHOSTSUBSYSTEM_CFG = 2001;
/*      */   
/*      */   public static final int NET_DVR_SET_ALARMHOSTSUBSYSTEM_CFG = 2002;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMHOST_SUBSYSTEM_CFG_EX = 2030;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMIN_PARAM = 1183;
/*      */   
/*      */   public static final int NET_DVR_SET_ALARMIN_PARAM = 1182;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMHOST_MAIN_STATUS = 1190;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMHOST_OTHER_STATUS = 1191;
/*      */   
/*      */   public static final int NET_DVR_GET_ALARMHOST_ENABLECFG = 1193;
/*      */   
/*      */   public static final int NET_DVR_ARM_ALARMHOST_SUBSYSTEM = 2036;
/*      */   
/*      */   public static final int NET_DVR_SET_SUBSYSTEM_BYPASS = 2028;
/*      */   
/*      */   public static final int NET_DVR_CANCEL_SUBSYSTEM_BYPASS = 2029;
/*      */   
/*      */   public static final int NET_DVR_GET_ZONE_CHANNEL_LINKAGE_CFG = 2208;
/*      */   
/*      */   public static final int NET_DVR_GET_CURRENT_VALID_PORT = 9300;
/*      */   
/*      */   public static final int NET_DVR_GET_CALLER_INFO = 16033;
/*      */   
/*      */   public static final int NET_DVR_REMOTECONTROL_GATEWAY = 16009;
/*      */   
/*      */   public static final int NET_DVR_GET_CALL_STATUS = 16034;
/*      */   
/*      */   public static final int NET_DVR_GET_SERVER_DEVICE_INFO = 16035;
/*      */   
/*      */   public static final int NET_DVR_SET_CALL_SIGNAL = 16036;
/*      */   
/*      */   public static final int COMM_ALARM = 4352;
/*      */   
/*      */   public static final int COMM_ALARM_V30 = 16384;
/*      */   
/*      */   public static final int NET_DVR_FILE_SUCCESS = 1000;
/*      */   
/*      */   public static final int NET_DVR_FILE_NOFIND = 1001;
/*      */   
/*      */   public static final int NET_DVR_ISFINDING = 1002;
/*      */   
/*      */   public static final int NET_DVR_NOMOREFILE = 1003;
/*      */   
/*      */   public static final int NET_DVR_FILE_EXCEPTION = 1004;
/*      */   
/*      */   public static final int NET_DVR_PLAYSTART = 1;
/*      */   
/*      */   public static final int NET_DVR_PLAYPAUSE = 3;
/*      */   
/*      */   public static final int NET_DVR_PLAYRESTART = 4;
/*      */   
/*      */   public static final int NET_DVR_PLAYGETPOS = 13;
/*      */   
/*      */   public static final int NET_DVR_GETTOTALFRAMES = 16;
/*      */   
/*      */   public static final int NET_DVR_GETTOTALTIME = 17;
/*      */   
/*      */   public static final int NET_DVR_SETSPEED = 24;
/*      */   
/*      */   public static final int NET_DVR_PLAYSETTIME = 26;
/*      */   
/*      */   public static final int NET_DVR_PLAYGETTOTALLEN = 27;
/*      */   
/*      */   public static final int DEVICE_SOFTHARDWARE_ABILITY = 1;
/*      */   
/*      */   public static final int DEVICE_NETWORK_ABILITY = 2;
/*      */   
/*      */   public static final int DEVICE_ENCODE_ALL_ABILITY = 3;
/*      */   
/*      */   public static final int DEVICE_ENCODE_CURRENT = 4;
/*      */   
/*      */   public static final int IPC_FRONT_PARAMETER = 5;
/*      */   
/*      */   public static final int IPC_UPGRADE_DESCRIPTION = 6;
/*      */   
/*      */   public static final int DEVICE_RAID_ABILITY = 7;
/*      */   
/*      */   public static final int DEVICE_ENCODE_ALL_ABILITY_V20 = 8;
/*      */   
/*      */   public static final int IPC_FRONT_PARAMETER_V20 = 9;
/*      */   
/*      */   public static final int DEVICE_ALARM_ABILITY = 10;
/*      */   
/*      */   public static final int DEVICE_DYNCHAN_ABILITY = 11;
/*      */   
/*      */   public static final int DEVICE_USER_ABILITY = 12;
/*      */   
/*      */   public static final int DEVICE_NETAPP_ABILITY = 13;
/*      */   
/*      */   public static final int DEVICE_VIDEOPIC_ABILITY = 14;
/*      */   
/*      */   public static final int DEVICE_JPEG_CAP_ABILITY = 15;
/*      */   
/*      */   public static final int DEVICE_SERIAL_ABILITY = 16;
/*      */   
/*      */   public static final int DEVICE_ABILITY_INFO = 17;
/*      */   
/*      */   public static final int IP_VIEW_DEV_ABILITY = 20;
/*      */   
/*      */   public static final int VCA_DEV_ABILITY = 256;
/*      */   
/*      */   public static final int VCA_CHAN_ABILITY = 272;
/*      */   
/*      */   public static final int MATRIXDECODER_ABILITY = 512;
/*      */   
/*      */   public static final int VIDEOPLATFORM_ABILITY = 528;
/*      */   
/*      */   public static final int MATRIXDECODER_ABILITY_V41 = 608;
/*      */   
/*      */   public static final int DECODER_ABILITY = 609;
/*      */   
/*      */   public static final int CODECARD_ABILITY = 625;
/*      */   
/*      */   public static final int SNAPCAMERA_ABILITY = 768;
/*      */   
/*      */   public static final int ITC_TRIGGER_MODE_ABILITY = 769;
/*      */   
/*      */   public static final int COMPRESSIONCFG_ABILITY = 1024;
/*      */   
/*      */   public static final int COMPRESSION_LIMIT = 1025;
/*      */   
/*      */   public static final int PIC_CAPTURE_ABILITY = 1026;
/*      */   
/*      */   public static final int IT_DEVICE_ABILITY = 1281;
/*      */   
/*      */   public static final int SCREENCONTROL_ABILITY = 1536;
/*      */   
/*      */   public static final int SCREENSERVER_ABILITY = 1552;
/*      */   
/*      */   public static final int FISHEYE_ABILITY = 1792;
/*      */   
/*      */   public static final int LOCAL_AREA_NETWORK = 0;
/*      */   
/*      */   public static final int WIDE_AREA_NETWORK = 1;
/*      */   
/*      */   public static final int STEP_READY = 0;
/*      */   
/*      */   public static final int STEP_RECV_DATA = 1;
/*      */   
/*      */   public static final int STEP_UPGRADE = 2;
/*      */   
/*      */   public static final int STEP_BACKUP = 3;
/*      */   
/*      */   public static final int STEP_SEARCH = 255;
/*      */   
/*      */   public static final int LOG_INFO_LEN = 11840;
/*      */   
/*      */   public static final int MAX_NAMELEN = 16;
/*      */   
/*      */   public static final int MAX_WINDOW_V40 = 64;
/*      */   
/*      */   public static final int MAX_STRINGNUM_V30 = 8;
/*      */   
/*      */   public static final int NET_DVR_DEV_ADDRESS_MAX_LEN = 129;
/*      */   
/*      */   public static final int EZVIZ_CLASSSESSION_LEN = 64;
/*      */   
/*      */   public static final int EZVIZ_DEVICEID_LEN = 32;
/*      */   
/*      */   public int NET_DVR_Login_V30(String sDvrIp, int iDvrPort, String sUserName, String sPassword, NET_DVR_DEVICEINFO_V30 DeviceInfo)
/*      */   {
/*  605 */     if (sUserName.length() > 64)
/*      */     {
/*  607 */       return -2;
/*      */     }
/*  609 */     byte[] byUserName = new byte[64];
/*  610 */     byte[] byUserName1 = new byte[64];
/*      */     try {
/*  612 */       byUserName1 = sUserName.getBytes("GB2312");
/*  613 */       for (int i = 0; i < byUserName1.length; i++)
/*      */       {
/*  615 */         byUserName[i] = byUserName1[i];
/*      */       }
/*  617 */       return NET_DVR_Login_V30(sDvrIp, iDvrPort, byUserName, sPassword, DeviceInfo);
/*      */     }
/*      */     catch (Exception localException) {}
/*      */     
/*  621 */     return -2;
/*      */   }
/*      */   
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   public boolean NET_DVR_GetDVRIPByResolveSvr_EX(String sServerIP, short wServerPort, String sDVRName, short wDVRNameLen, String sDVRSerialNumber, short wDVRSerialLen, NET_DVR_RESOLVE_DEVICEINFO lpDeviceInfo)
/*      */   {
/* 1077 */     byte[] byDvrName = new byte[''];
/* 1078 */     byte[] byDvrName1 = new byte[''];
/*      */     try {
/* 1080 */       byDvrName1 = sDVRName.getBytes("GB2312");
/* 1081 */       for (int i = 0; i < byDvrName1.length; i++)
/*      */       {
/* 1083 */         byDvrName[i] = byDvrName1[i];
/*      */       }
/* 1085 */       return NET_DVR_GetDVRIPByResolveSvr_EX(sServerIP, wServerPort, byDvrName, (short)byDvrName1.length, sDVRSerialNumber, wDVRSerialLen, lpDeviceInfo);
/*      */     }
/*      */     catch (Exception localException) {}
/*      */     
/* 1089 */     return false;
/*      */   }
/*      */   
/*      */   public native boolean NET_DVR_Init();
/*      */   
/*      */   public native boolean NET_DVR_Cleanup();
/*      */   
/*      */   public native boolean NET_DVR_SetConnectTime(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_SetReconnect(int paramInt, boolean paramBoolean);
/*      */   
/*      */   public native int NET_DVR_GetLastError();
/*      */   
/*      */   public native int NET_DVR_GetSDKVersion();
/*      */   
/*      */   public native int NET_DVR_GetSDKBuildVersion();
/*      */   
/*      */   public native boolean NET_DVR_SetExceptionCallBack(ExceptionCallBack paramExceptionCallBack);
/*      */   
/*      */   public native int NET_DVR_Login_V30(String paramString1, int paramInt, byte[] paramArrayOfByte, String paramString2, NET_DVR_DEVICEINFO_V30 paramNET_DVR_DEVICEINFO_V30);
/*      */   
/*      */   public native boolean NET_DVR_Logout_V30(int paramInt);
/*      */   
/*      */   public native int NET_DVR_RealPlay_V30(int paramInt, NET_DVR_CLIENTINFO paramNET_DVR_CLIENTINFO, RealPlayCallBack paramRealPlayCallBack, boolean paramBoolean);
/*      */   
/*      */   public native int NET_DVR_RealPlay_V40(int paramInt, NET_DVR_PREVIEWINFO paramNET_DVR_PREVIEWINFO, RealPlayCallBack paramRealPlayCallBack);
/*      */   
/*      */   public native boolean NET_DVR_StopRealPlay(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_MakeKeyFrame(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_MakeKeyFrameSub(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_ClientGetVideoEffect(int paramInt, NET_DVR_VIDEOEFFECT paramNET_DVR_VIDEOEFFECT);
/*      */   
/*      */   public native boolean NET_DVR_ClientSetVideoEffect(int paramInt, NET_DVR_VIDEOEFFECT paramNET_DVR_VIDEOEFFECT);
/*      */   
/*      */   public native boolean NET_DVR_PTZControl(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public native boolean NET_DVR_PTZControl_Other(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   public native boolean NET_DVR_PTZControlWithSpeed(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   public native boolean NET_DVR_PTZControlWithSpeed_Other(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
/*      */   
/*      */   public native boolean NET_DVR_PTZPreset(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public native boolean NET_DVR_PTZPreset_Other(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*      */   
/*      */   public native boolean NET_DVR_PTZCruise(int paramInt1, int paramInt2, byte paramByte1, byte paramByte2, short paramShort);
/*      */   
/*      */   public native boolean NET_DVR_PTZCruise_Other(int paramInt1, int paramInt2, int paramInt3, byte paramByte1, byte paramByte2, short paramShort);
/*      */   
/*      */   public native boolean NET_DVR_PTZTrack(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_PTZTrack_Other(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public native boolean NET_DVR_GetPTZProtocol(int paramInt, NET_DVR_PTZCFG paramNET_DVR_PTZCFG);
/*      */   
/*      */   public native boolean NET_DVR_RebootDVR(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_ShutDownDVR(int paramInt);
/*      */   
/*      */   public native int NET_DVR_StartVoiceCom_MR_V30(int paramInt1, int paramInt2, VoiceDataCallBack paramVoiceDataCallBack);
/*      */   
/*      */   public native boolean NET_DVR_VoiceComSendData(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_StopVoiceCom(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_GetDVRConfig(int paramInt1, int paramInt2, int paramInt3, NET_DVR_CONFIG paramNET_DVR_CONFIG);
/*      */   
/*      */   public native boolean NET_DVR_SetDVRConfig(int paramInt1, int paramInt2, int paramInt3, NET_DVR_CONFIG paramNET_DVR_CONFIG);
/*      */   
/*      */   public native boolean NET_DVR_GetAlarmOut_V30(int paramInt, NET_DVR_ALARMOUTSTATUS_V30 paramNET_DVR_ALARMOUTSTATUS_V30);
/*      */   
/*      */   public native boolean NET_DVR_SetAlarmOut(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public native int NET_DVR_SetupAlarmChan_V30(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_CloseAlarmChan_V30(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_SetDVRMessageCallBack_V30(AlarmCallBack_V30 paramAlarmCallBack_V30);
/*      */   
/*      */   public native int NET_DVR_FindFile_V30(int paramInt, NET_DVR_FILECOND paramNET_DVR_FILECOND);
/*      */   
/*      */   public native int NET_DVR_FindNextFile_V30(int paramInt, NET_DVR_FINDDATA_V30 paramNET_DVR_FINDDATA_V30);
/*      */   
/*      */   public native boolean NET_DVR_FindClose_V30(int paramInt);
/*      */   
/*      */   public native int NET_DVR_PlayBackByName(int paramInt, String paramString);
/*      */   
/*      */   public native int NET_DVR_PlayBackByTime(int paramInt1, int paramInt2, NET_DVR_TIME paramNET_DVR_TIME1, NET_DVR_TIME paramNET_DVR_TIME2);
/*      */   
/*      */   public native boolean NET_DVR_PlayBackControl_V40(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3, NET_DVR_PLAYBACK_INFO paramNET_DVR_PLAYBACK_INFO);
/*      */   
/*      */   public native boolean NET_DVR_StopPlayBack(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_SetPlayDataCallBack(int paramInt, PlaybackCallBack paramPlaybackCallBack);
/*      */   
/*      */   public native int NET_DVR_GetPlayBackPos(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_PlayBackSaveData(int paramInt, String paramString);
/*      */   
/*      */   public native boolean NET_DVR_StopPlayBackSave(int paramInt);
/*      */   
/*      */   public native int NET_DVR_GetFileByName(int paramInt, String paramString1, String paramString2);
/*      */   
/*      */   public native int NET_DVR_GetFileByTime(int paramInt1, int paramInt2, NET_DVR_TIME paramNET_DVR_TIME1, NET_DVR_TIME paramNET_DVR_TIME2, String paramString);
/*      */   
/*      */   public native boolean NET_DVR_StopGetFile(int paramInt);
/*      */   
/*      */   public native int NET_DVR_GetDownloadPos(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_GetDVRIPByResolveSvr_EX(String paramString1, short paramShort1, byte[] paramArrayOfByte, short paramShort2, String paramString2, short paramShort3, NET_DVR_RESOLVE_DEVICEINFO paramNET_DVR_RESOLVE_DEVICEINFO);
/*      */   
/*      */   public native boolean NET_DVR_PTZSelZoomIn(int paramInt, NET_DVR_POINT_FRAME paramNET_DVR_POINT_FRAME);
/*      */   
/*      */   public native boolean NET_DVR_PTZSelZoomIn_EX(int paramInt1, int paramInt2, NET_DVR_POINT_FRAME paramNET_DVR_POINT_FRAME);
/*      */   
/*      */   public native boolean NET_DVR_CaptureJPEGPicture(int paramInt1, int paramInt2, NET_DVR_JPEGPARA paramNET_DVR_JPEGPARA, String paramString);
/*      */   
/*      */   public native boolean NET_DVR_CaptureJPEGPicture_NEW(int paramInt1, int paramInt2, NET_DVR_JPEGPARA paramNET_DVR_JPEGPARA, byte[] paramArrayOfByte, int paramInt3, INT_PTR paramINT_PTR);
/*      */   
/*      */   public native boolean NET_DVR_GetCompressionAbility(int paramInt1, int paramInt2, NET_DVR_COMPRESSIONCFG_ABILITY paramNET_DVR_COMPRESSIONCFG_ABILITY);
/*      */   
/*      */   public native boolean NET_DVR_SetLogToFile(int paramInt, String paramString, boolean paramBoolean);
/*      */   
/*      */   public native boolean NET_DVR_GetCurrentAudioCompress(int paramInt, NET_DVR_COMPRESSION_AUDIO paramNET_DVR_COMPRESSION_AUDIO);
/*      */   
/*      */   public native int NET_DVR_SerialStart(int paramInt1, int paramInt2, SerialDataCallBack paramSerialDataCallBack);
/*      */   
/*      */   public native boolean NET_DVR_SerialSend(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
/*      */   
/*      */   public native boolean NET_DVR_SerialStop(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_SendToSerialPort(int paramInt1, int paramInt2, int paramInt3, byte[] paramArrayOfByte, int paramInt4);
/*      */   
/*      */   public native boolean NET_DVR_SendTo232Port(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_GetXMLAbility(int paramInt1, int paramInt2, byte[] paramArrayOfByte1, int paramInt3, byte[] paramArrayOfByte2, int paramInt4, INT_PTR paramINT_PTR);
/*      */   
/*      */   public native boolean NET_DVR_SetSDKLocalConfig(NET_DVR_SDKLOCAL_CFG paramNET_DVR_SDKLOCAL_CFG);
/*      */   
/*      */   public native boolean NET_DVR_GetSDKLocalConfig(NET_DVR_SDKLOCAL_CFG paramNET_DVR_SDKLOCAL_CFG);
/*      */   
/*      */   public native boolean NET_DVR_SaveRealData(int paramInt, String paramString);
/*      */   
/*      */   public native boolean NET_DVR_StopSaveRealData(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_SetSimAbilityPath(String paramString1, String paramString2);
/*      */   
/*      */   public native boolean NET_DVR_StartDVRRecord(int paramInt1, int paramInt2, int paramInt3);
/*      */   
/*      */   public native boolean NET_DVR_StopDVRRecord(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_GetDVRWorkState_V30(int paramInt, NET_DVR_WORKSTATE_V30 paramNET_DVR_WORKSTATE_V30);
/*      */   
/*      */   public native int NET_DVR_ZeroStartPlay(int paramInt, NET_DVR_CLIENTINFO paramNET_DVR_CLIENTINFO, RealPlayCallBack paramRealPlayCallBack, boolean paramBoolean);
/*      */   
/*      */   public native boolean NET_DVR_ZeroStopPlay(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_SetNetworkEnvironment(int paramInt);
/*      */   
/*      */   public native int NET_DVR_Upgrade(int paramInt, String paramString);
/*      */   
/*      */   public native int NET_DVR_GetUpgradeProgress(int paramInt);
/*      */   
/*      */   public native int NET_DVR_GetUpgradeState(int paramInt);
/*      */   
/*      */   public native int NET_DVR_GetUpgradeStep(int paramInt, INT_PTR paramINT_PTR);
/*      */   
/*      */   public native boolean NET_DVR_CloseUpgradeHandle(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_SetRecvTimeOut(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_GetUpnpNatState(int paramInt, NET_DVR_UPNP_NAT_STATE paramNET_DVR_UPNP_NAT_STATE);
/*      */   
/*      */   public native String NET_DVR_GetErrorMsg(INT_PTR paramINT_PTR);
/*      */   
/*      */   public native int NET_DVR_FormatDisk(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_GetFormatProgress(int paramInt, INT_PTR paramINT_PTR1, INT_PTR paramINT_PTR2, INT_PTR paramINT_PTR3);
/*      */   
/*      */   public native boolean NET_DVR_CloseFormatHandle(int paramInt);
/*      */   
/*      */   public native long NET_DVR_FindDVRLog_V30(long paramLong1, long paramLong2, int paramInt1, int paramInt2, NET_DVR_TIME paramNET_DVR_TIME1, NET_DVR_TIME paramNET_DVR_TIME2, boolean paramBoolean);
/*      */   
/*      */   public native long NET_DVR_FindNextLog_V30(long paramLong, NET_DVR_LOG_V30 paramNET_DVR_LOG_V30);
/*      */   
/*      */   public native boolean NET_DVR_FindLogClose_V30(long paramLong);
/*      */   
/*      */   public native boolean NET_DVR_UpdateRecordIndex(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_ClickKey(int paramInt1, int paramInt2);
/*      */   
/*      */   public native int NET_DVR_FindFileByEvent(int paramInt, NET_DVR_SEARCH_EVENT_PARAM paramNET_DVR_SEARCH_EVENT_PARAM);
/*      */   
/*      */   public native int NET_DVR_FindNextEvent(int paramInt, NET_DVR_SEARCH_EVENT_RET paramNET_DVR_SEARCH_EVENT_RET);
/*      */   
/*      */   public native boolean NET_DVR_InquestStartCDW_V30(int paramInt, NET_DVR_INQUEST_ROOM paramNET_DVR_INQUEST_ROOM, boolean paramBoolean);
/*      */   
/*      */   public native boolean NET_DVR_InquestStopCDW_V30(int paramInt, NET_DVR_INQUEST_ROOM paramNET_DVR_INQUEST_ROOM, boolean paramBoolean);
/*      */   
/*      */   public native boolean NET_DVR_InquestGetPIPStatus_V40(int paramInt, NET_DVR_INQUEST_ROOM paramNET_DVR_INQUEST_ROOM, NET_DVR_INQUEST_PIP_STATUS_V40 paramNET_DVR_INQUEST_PIP_STATUS_V40);
/*      */   
/*      */   public native boolean NET_DVR_InquestSetPIPStatus_V40(int paramInt, NET_DVR_INQUEST_ROOM paramNET_DVR_INQUEST_ROOM, NET_DVR_INQUEST_PIP_STATUS_V40 paramNET_DVR_INQUEST_PIP_STATUS_V40);
/*      */   
/*      */   public native boolean NET_DVR_GetDeviceConfig(int paramInt1, int paramInt2, NET_DVR_CONDITION paramNET_DVR_CONDITION, NET_DVR_CONFIG paramNET_DVR_CONFIG);
/*      */   
/*      */   public native boolean NET_DVR_SetDeviceConfig(int paramInt1, int paramInt2, NET_DVR_CONDITION paramNET_DVR_CONDITION, NET_DVR_CONFIG paramNET_DVR_CONFIG);
/*      */   
/*      */   public native int NET_DVR_SerialStart_V40(int paramInt, NET_DVR_SERIAL_COND paramNET_DVR_SERIAL_COND, SerialDataCallBackV40 paramSerialDataCallBackV40);
/*      */   
/*      */   public native boolean NET_DVR_AlarmHostSubSystemSetupAlarmChan(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_AlarmHostSubSystemCloseAlarmChan(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_AlarmHostClearAlarm(int paramInt1, int paramInt2);
/*      */   
/*      */   public native boolean NET_DVR_RemoteControl(int paramInt1, int paramInt2, NET_DVR_CONTROL paramNET_DVR_CONTROL);
/*      */   
/*      */   public native boolean NET_DVR_AlarmHostSetupAlarmChan(int paramInt, NET_DVR_ALARMIN_SETUP paramNET_DVR_ALARMIN_SETUP);
/*      */   
/*      */   public native boolean NET_DVR_AlarmHostCloseAlarmChan(int paramInt, NET_DVR_ALARMIN_SETUP paramNET_DVR_ALARMIN_SETUP);
/*      */   
/*      */   public native boolean NET_DVR_BypassAlarmChan(int paramInt, NET_DVR_ALARMIN_SETUP paramNET_DVR_ALARMIN_SETUP);
/*      */   
/*      */   public native boolean NET_DVR_UnBypassAlarmChan(int paramInt, NET_DVR_ALARMIN_SETUP paramNET_DVR_ALARMIN_SETUP);
/*      */   
/*      */   public native int NET_DVR_CreateEzvizUser(NET_DVR_EZVIZ_USER_LOGIN_INFO paramNET_DVR_EZVIZ_USER_LOGIN_INFO, NET_DVR_DEVICEINFO_V30 paramNET_DVR_DEVICEINFO_V30);
/*      */   
/*      */   public native boolean NET_DVR_DeleteEzvizUser(int paramInt);
/*      */   
/*      */   public native boolean NET_DVR_GetDeviceStatus(int paramInt1, int paramInt2, NET_DVR_CONDITION paramNET_DVR_CONDITION, NET_DVR_STATUS paramNET_DVR_STATUS);
/*      */   
/*      */   public native boolean NET_DVR_GetAddrInfoByServer(int paramInt, NET_DVR_ADDR_QUERY_COND paramNET_DVR_ADDR_QUERY_COND, NET_DVR_ADDR_QUERY_RET paramNET_DVR_ADDR_QUERY_RET);
/*      */   
/*      */   public native boolean NET_DVR_ActivateDevice(String paramString, int paramInt, NET_DVR_ACTIVATECFG paramNET_DVR_ACTIVATECFG);
/*      */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\HCNetSDK.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */