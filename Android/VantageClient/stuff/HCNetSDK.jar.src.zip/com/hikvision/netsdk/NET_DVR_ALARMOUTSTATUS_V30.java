/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ALARMOUTSTATUS_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/* 10 */   public byte[] Output = new byte[96];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMOUTSTATUS_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */