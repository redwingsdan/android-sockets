/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_UPNP_PORT_STATE
/*    */ {
/*    */   public int dwEnabled;
/*    */   
/*    */ 
/*    */   public int wInternalPort;
/*    */   
/*    */ 
/*    */   public int wExternalPort;
/*    */   
/*    */ 
/*    */   public int dwStatus;
/*    */   
/*    */ 
/* 19 */   public NET_DVR_IPADDR struNatExternalIp = new NET_DVR_IPADDR();
/*    */   
/* 21 */   public NET_DVR_IPADDR struNatInternalIp = new NET_DVR_IPADDR();
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_UPNP_PORT_STATE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */