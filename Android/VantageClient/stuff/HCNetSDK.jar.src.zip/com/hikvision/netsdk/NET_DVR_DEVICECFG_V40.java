/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_DEVICECFG_V40
/*    */   extends NET_DVR_CONFIG
/*    */ {
/* 10 */   public byte[] byDevTypeName = new byte[24];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DEVICECFG_V40.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */