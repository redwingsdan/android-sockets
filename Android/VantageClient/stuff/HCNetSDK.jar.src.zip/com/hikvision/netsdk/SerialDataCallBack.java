package com.hikvision.netsdk;

public abstract interface SerialDataCallBack
{
  public abstract void fSerialDataCallBack(int paramInt1, byte[] paramArrayOfByte, int paramInt2);
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\SerialDataCallBack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */