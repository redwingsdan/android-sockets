/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ALARMINFO
/*    */   extends NET_DVR_BASE_ALARM
/*    */ {
/*    */   public int dwAlarmType;
/*    */   
/*    */ 
/*    */   public int dwAlarmInputNumber;
/*    */   
/* 13 */   public int[] dwAlarmOutputNumber = new int[4];
/*    */   
/* 15 */   public int[] dwAlarmRelateChannel = new int[16];
/*    */   
/* 17 */   public int[] dwChannel = new int[16];
/*    */   
/* 19 */   public int[] dwDiskNumber = new int[16];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMINFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */