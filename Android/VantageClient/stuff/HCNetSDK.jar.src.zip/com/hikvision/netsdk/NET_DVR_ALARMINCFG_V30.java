/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ALARMINCFG_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   public byte[] sAlarmInName = new byte[32];
/*    */   
/*    */   public byte byAlarmType;
/*    */   
/*    */   public byte byAlarmInHandle;
/*    */   
/*    */   public byte byChannel;
/*    */   
/* 17 */   public NET_DVR_HANDLEEXCEPTION_V30 struAlarmHandleType = new NET_DVR_HANDLEEXCEPTION_V30();
/*    */   
/* 19 */   public NET_DVR_SCHEDTIME[][] struAlarmTime = new NET_DVR_SCHEDTIME[7][8];
/*    */   
/* 21 */   public byte[] byRelRecordChan = new byte[64];
/*    */   
/* 23 */   public byte[] byEnablePreset = new byte[64];
/*    */   
/* 25 */   public byte[] byPresetNo = new byte[64];
/*    */   
/* 27 */   public byte[] byEnableCruise = new byte[64];
/*    */   
/* 29 */   public byte[] byCruiseNo = new byte[64];
/*    */   
/* 31 */   public byte[] byEnablePtzTrack = new byte[64];
/*    */   
/* 33 */   public byte[] byPTZTrack = new byte[64];
/*    */   
/*    */   public NET_DVR_ALARMINCFG_V30()
/*    */   {
/* 37 */     for (int i = 0; i < 7; i++)
/*    */     {
/* 39 */       for (int j = 0; j < 8; j++)
/*    */       {
/* 41 */         this.struAlarmTime[i][j] = new NET_DVR_SCHEDTIME();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMINCFG_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */