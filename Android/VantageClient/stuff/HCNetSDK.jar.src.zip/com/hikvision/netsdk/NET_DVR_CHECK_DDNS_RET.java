/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_CHECK_DDNS_RET
/*    */   extends NET_DVR_ADDR_QUERY_RET
/*    */ {
/*    */   public byte byDevStatus;
/*    */   
/*    */ 
/*    */   public int wRegionID;
/*    */   
/* 13 */   public NET_DVR_QUERY_DDNS_RET struQueryRet = new NET_DVR_QUERY_DDNS_RET();
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_CHECK_DDNS_RET.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */