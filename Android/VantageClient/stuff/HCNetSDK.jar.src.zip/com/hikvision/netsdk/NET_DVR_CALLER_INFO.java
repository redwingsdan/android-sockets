/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ public class NET_DVR_CALLER_INFO
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int wBuildingNo;
/*    */   
/*    */   public int wFloorNo;
/*    */   
/*    */   public byte byZoneNo;
/*    */   
/*    */   public byte byUnitNo;
/*    */   
/*    */   public byte byDevNo;
/*    */   public byte byDevType;
/* 17 */   public byte[] byRes = new byte[100];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_CALLER_INFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */