/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_PTZ_PROTOCOL
/*    */ {
/*    */   public int dwType;
/*    */   
/*    */ 
/* 11 */   public byte[] byDescribe = new byte[16];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PTZ_PROTOCOL.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */