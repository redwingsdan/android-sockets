/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_INQUEST_PIP_STATUS_V40
/*    */ {
/*    */   public byte byBaseChan;
/*    */   
/*    */ 
/*    */   public byte byBackChan;
/*    */   
/*    */ 
/*    */   public byte byPIPMode;
/*    */   
/*    */   public byte byPipCount;
/*    */   
/*    */   public byte byPicShowMode;
/*    */   
/* 19 */   public NET_DVR_INQUEST_PIP_PARAM_V40[] struPipPara = new NET_DVR_INQUEST_PIP_PARAM_V40[16];
/*    */   
/* 21 */   public NET_DVR_INQUEST_PIP_STATUS_V40() { for (int i = 0; i < 16; i++)
/*    */     {
/* 23 */       this.struPipPara[i] = new NET_DVR_INQUEST_PIP_PARAM_V40();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_INQUEST_PIP_STATUS_V40.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */