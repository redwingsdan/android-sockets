/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ETHERNET_V30
/*    */ {
/* 10 */   public NET_DVR_IPADDR struDVRIP = new NET_DVR_IPADDR();
/*    */   
/* 12 */   public NET_DVR_IPADDR struDVRIPMask = new NET_DVR_IPADDR();
/*    */   
/*    */ 
/*    */   public int dwNetInterface;
/*    */   
/*    */ 
/*    */   public int wDVRPort;
/*    */   
/*    */   public int wMTU;
/*    */   
/* 22 */   public byte[] byMACAddr = new byte[6];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ETHERNET_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */