package com.hikvision.netsdk;

public class PTZPresetCmd
{
  public static final int SET_PRESET = 8;
  public static final int CLE_PRESET = 9;
  public static final int GOTO_PRESET = 39;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\PTZPresetCmd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */