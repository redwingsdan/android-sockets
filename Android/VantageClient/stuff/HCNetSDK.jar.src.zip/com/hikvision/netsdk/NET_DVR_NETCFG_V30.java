/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_NETCFG_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/* 12 */   public NET_DVR_ETHERNET_V30[] struEtherNet = new NET_DVR_ETHERNET_V30[2];
/*    */   
/* 14 */   public NET_DVR_IPADDR struAlarmHostIpAddr = new NET_DVR_IPADDR();
/*    */   
/*    */   public int wAlarmHostIpPort;
/*    */   
/*    */   public byte byUseDhcp;
/*    */   
/* 20 */   public NET_DVR_IPADDR struDnsServer1IpAddr = new NET_DVR_IPADDR();
/*    */   
/* 22 */   public NET_DVR_IPADDR struDnsServer2IpAddr = new NET_DVR_IPADDR();
/*    */   
/*    */ 
/*    */ 
/* 26 */   public byte[] byIpResolver = new byte[64];
/*    */   
/*    */   public int wIpResolverPort;
/*    */   
/*    */   public int wHttpPortNo;
/*    */   
/* 32 */   public NET_DVR_IPADDR struMulticastIpAddr = new NET_DVR_IPADDR();
/*    */   
/* 34 */   public NET_DVR_IPADDR struGatewayIpAddr = new NET_DVR_IPADDR();
/*    */   
/* 36 */   public NET_DVR_PPPOECFG struPPPoE = new NET_DVR_PPPOECFG();
/*    */   
/*    */   public NET_DVR_NETCFG_V30() {
/* 39 */     for (int i = 0; i < 2; i++) {
/* 40 */       this.struEtherNet[i] = new NET_DVR_ETHERNET_V30();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_NETCFG_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */