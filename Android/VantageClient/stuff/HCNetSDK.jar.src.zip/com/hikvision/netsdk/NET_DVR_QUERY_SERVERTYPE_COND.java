/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_QUERY_SERVERTYPE_COND
/*    */   extends NET_DVR_ADDR_QUERY_COND
/*    */ {
/*    */   public int wSvrType;
/*    */   
/*    */ 
/* 11 */   public byte[] szSvrAddr = new byte[64];
/*    */   
/* 13 */   public byte[] szClientVersion = new byte[64];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_QUERY_SERVERTYPE_COND.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */