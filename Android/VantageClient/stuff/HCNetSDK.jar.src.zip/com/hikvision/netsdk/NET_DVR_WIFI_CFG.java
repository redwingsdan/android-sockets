/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_WIFI_CFG
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   NET_DVR_WIFIETHERNET struEtherNet = new NET_DVR_WIFIETHERNET();
/*    */   
/* 11 */   public byte[] sEssid = new byte[32];
/*    */   
/*    */   public int dwMode;
/*    */   
/*    */   public int dwSecurity;
/*    */   
/* 17 */   public WEP wep = new WEP();
/*    */   
/* 19 */   public WPA_PSK wpa_psk = new WPA_PSK();
/*    */   
/* 21 */   public WPA_WPA2 wpa_wpa2 = new WPA_WPA2();
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_WIFI_CFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */