/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public class NET_DVR_AP_INFO
/*   */ {
/* 9 */   public byte[] sSsid = new byte[32];
/*   */   public int dwMode;
/*   */   public int dwSecurity;
/*   */   public int dwChannel;
/*   */   public int dwSignalStrength;
/*   */   public int dwSpeed;
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_AP_INFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */