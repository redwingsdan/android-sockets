/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_SDKLOCAL_CFG
/*    */ {
/*    */   public byte byEnableAbilityParse;
/*    */   
/*    */ 
/* 10 */   public byte[] byProtectKey = new byte[''];
/*    */   public byte byCompatibleType;
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SDKLOCAL_CFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */