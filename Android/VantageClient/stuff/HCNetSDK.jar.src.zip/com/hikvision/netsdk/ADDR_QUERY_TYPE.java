package com.hikvision.netsdk;

public class ADDR_QUERY_TYPE
{
  public static final int QUERYSVR_BY_COUNTRYID = 0;
  public static final int QUERYSVR_BY_SERVERTYPE = 1;
  public static final int QUERYDEV_BY_NICKNAME_DDNS = 2;
  public static final int QUERYDEV_BY_SERIAL_DDNS = 3;
  public static final int CHECKDEV_BY_NICKNAME_DDNS = 4;
  public static final int CHECKDEV_BY_SERIAL_DDNS = 5;
  public static final int QUERYDEV_BY_NICKNAME_IPSERVER = 6;
  public static final int QUERYDEV_BY_SERIAL_IPSERVER = 7;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\ADDR_QUERY_TYPE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */