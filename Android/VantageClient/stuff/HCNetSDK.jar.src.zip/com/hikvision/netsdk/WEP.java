/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WEP
/*    */ {
/*    */   public int dwAuthentication;
/*    */   
/*    */ 
/*    */   public int dwKeyLength;
/*    */   
/*    */ 
/*    */   public int dwKeyType;
/*    */   
/*    */   public int dwActive;
/*    */   
/* 17 */   public byte[][] sKeyInfo = new byte[4][33];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\WEP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */