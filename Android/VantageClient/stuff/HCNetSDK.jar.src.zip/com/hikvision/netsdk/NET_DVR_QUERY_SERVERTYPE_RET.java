/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public class NET_DVR_QUERY_SERVERTYPE_RET
/*   */   extends NET_DVR_ADDR_QUERY_RET
/*   */ {
/* 9 */   public byte[] szSvrAddr = new byte[64];
/*   */   public int wSvrPort;
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_QUERY_SERVERTYPE_RET.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */