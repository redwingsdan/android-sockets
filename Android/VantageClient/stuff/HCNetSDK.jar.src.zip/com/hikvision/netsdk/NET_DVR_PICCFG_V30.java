/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_PICCFG_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/* 10 */   public byte[] sChanName = new byte[32];
/*    */   
/*    */   public int dwVideoFormat;
/*    */   
/* 14 */   public NET_DVR_VICOLOR struViColor = new NET_DVR_VICOLOR();
/*    */   
/*    */   public int dwShowChanName;
/*    */   
/*    */   public short wShowNameTopLeftX;
/*    */   
/*    */   public short wShowNameTopLeftY;
/*    */   
/* 22 */   public NET_DVR_VILOST_V30 struVILost = new NET_DVR_VILOST_V30();
/*    */   
/* 24 */   public NET_DVR_MOTION_V30 struMotion = new NET_DVR_MOTION_V30();
/*    */   
/* 26 */   public NET_DVR_HIDEALARM_V30 struHideAlarm = new NET_DVR_HIDEALARM_V30();
/*    */   
/*    */   public int dwEnableHide;
/*    */   
/* 30 */   public NET_DVR_SHELTER[] struShelter = new NET_DVR_SHELTER[4];
/*    */   
/*    */ 
/*    */   public int dwShowOsd;
/*    */   
/*    */ 
/*    */   public short wOSDTopLeftX;
/*    */   
/*    */ 
/*    */   public short wOSDTopLeftY;
/*    */   
/*    */ 
/*    */   public byte byOSDType;
/*    */   
/*    */ 
/*    */   public byte byDispWeek;
/*    */   
/*    */ 
/*    */   public byte byOSDAttrib;
/*    */   
/*    */ 
/*    */   public byte byHourOsdType;
/*    */   
/*    */ 
/*    */   public byte byFontSize;
/*    */   
/*    */ 
/*    */   public NET_DVR_PICCFG_V30()
/*    */   {
/* 59 */     for (int i = 0; i < 4; i++)
/*    */     {
/* 61 */       this.struShelter[i] = new NET_DVR_SHELTER();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PICCFG_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */