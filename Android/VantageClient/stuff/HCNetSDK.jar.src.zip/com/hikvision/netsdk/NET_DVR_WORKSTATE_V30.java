/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_WORKSTATE_V30
/*    */ {
/*    */   public int dwDeviceStatic;
/*    */   
/*    */ 
/* 11 */   public NET_DVR_DISKSTATE[] struHardDiskStatic = new NET_DVR_DISKSTATE[33];
/*    */   
/* 13 */   public NET_DVR_CHANNELSTATE_V30[] struChanStatic = new NET_DVR_CHANNELSTATE_V30[64];
/*    */   
/* 15 */   public byte[] byAlarmInStatic = new byte[' '];
/*    */   
/* 17 */   public byte[] byAlarmOutStatic = new byte[96];
/*    */   
/*    */   public int dwLocalDisplay;
/*    */   
/* 21 */   public byte[] byAudioChanStatus = new byte[2];
/*    */   
/*    */   public NET_DVR_WORKSTATE_V30() {
/* 24 */     for (int i = 0; i < 33; i++) {
/* 25 */       this.struHardDiskStatic[i] = new NET_DVR_DISKSTATE();
/*    */     }
/* 27 */     for (int i = 0; i < 64; i++) {
/* 28 */       this.struChanStatic[i] = new NET_DVR_CHANNELSTATE_V30();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_WORKSTATE_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */