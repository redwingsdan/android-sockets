package com.hikvision.netsdk;

public class PlaybackControlCommand
{
  public static final int NET_DVR_PLAYSTART = 1;
  public static final int NET_DVR_PLAYPAUSE = 3;
  public static final int NET_DVR_PLAYRESTART = 4;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\PlaybackControlCommand.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */