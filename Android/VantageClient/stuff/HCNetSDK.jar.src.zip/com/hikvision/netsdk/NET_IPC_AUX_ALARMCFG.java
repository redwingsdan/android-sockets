/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_IPC_AUX_ALARMCFG
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   public NET_IPC_SINGLE_AUX_ALARMCFG[] struAlarm = new NET_IPC_SINGLE_AUX_ALARMCFG[8];
/*    */   
/*    */   public NET_IPC_AUX_ALARMCFG()
/*    */   {
/* 13 */     for (int i = 0; i < 8; i++)
/*    */     {
/* 15 */       this.struAlarm[i] = new NET_IPC_SINGLE_AUX_ALARMCFG();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_IPC_AUX_ALARMCFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */