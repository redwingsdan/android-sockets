/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_TRIAL_HOST_STATUS
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   public int[] dwFanSpeed = new int[8];
/*    */   
/* 11 */   public short[] wMainBoardTemp = new short[8];
/*    */   
/* 13 */   public byte[] byFpgaTempWarn = new byte[8];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_TRIAL_HOST_STATUS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */