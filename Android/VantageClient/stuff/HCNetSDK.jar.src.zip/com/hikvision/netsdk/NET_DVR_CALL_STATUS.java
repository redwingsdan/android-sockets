/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ public class NET_DVR_CALL_STATUS
/*   */   extends NET_DVR_STATUS
/*   */ {
/*   */   public byte byCallStatus;
/* 7 */   public byte[] byRes = new byte[127];
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_CALL_STATUS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */