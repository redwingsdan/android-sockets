/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_ALARMIN_PARAM extends NET_DVR_CONFIG
/*    */ {
/*  5 */   public byte[] byName = new byte[32];
/*    */   
/*    */   public int wDetectorType;
/*    */   
/*    */   public byte byType;
/*    */   
/*    */   public byte byUploadAlarmRecoveryReport;
/*    */   
/*    */   public int dwParam;
/*    */   
/* 15 */   public NET_DVR_SCHEDTIME[][] struAlarmTime = new NET_DVR_SCHEDTIME[7][4];
/*    */   
/* 17 */   public byte[] byAssociateAlarmOut = new byte['Ȁ'];
/*    */   
/* 19 */   public byte[] byAssociateSirenOut = new byte[8];
/*    */   
/*    */   public byte bySensitivityParam;
/*    */   
/*    */   public byte byArrayBypass;
/*    */   
/*    */   public byte byJointSubSystem;
/*    */   
/*    */   public byte byModuleStatus;
/*    */   
/*    */   public int wModuleAddress;
/*    */   
/*    */   public byte byModuleChan;
/*    */   
/*    */   public byte byModuleType;
/*    */   
/*    */   public int wZoneIndex;
/*    */   
/*    */   public int wInDelay;
/*    */   
/*    */   public int wOutDelay;
/*    */   
/*    */   public byte byAlarmType;
/*    */   
/* 43 */   public byte[] byRes2 = new byte[37];
/*    */   
/*    */   public NET_DVR_ALARMIN_PARAM()
/*    */   {
/* 47 */     for (int i = 0; i < 7; i++)
/*    */     {
/* 49 */       for (int j = 0; j < 4; j++)
/*    */       {
/* 51 */         this.struAlarmTime[i][j] = new NET_DVR_SCHEDTIME();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMIN_PARAM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */