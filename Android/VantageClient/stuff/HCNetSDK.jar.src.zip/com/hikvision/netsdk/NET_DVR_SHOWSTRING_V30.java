/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_SHOWSTRING_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*  9 */   public NET_DVR_SHOWSTRINGINFO[] struStringInfo = new NET_DVR_SHOWSTRINGINFO[8];
/*    */   
/*    */   public NET_DVR_SHOWSTRING_V30() {
/* 12 */     for (int i = 0; i < 8; i++)
/*    */     {
/* 14 */       this.struStringInfo[i] = new NET_DVR_SHOWSTRINGINFO();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SHOWSTRING_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */