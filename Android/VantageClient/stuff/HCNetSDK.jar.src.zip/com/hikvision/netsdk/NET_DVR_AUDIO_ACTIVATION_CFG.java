/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_AUDIO_ACTIVATION_CFG
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public byte byEnable;
/*    */   
/*    */ 
/*    */   public int dwChanNo;
/*    */   
/*    */   public byte bySensitivity;
/*    */   
/*    */   public byte byPriority;
/*    */   
/*    */   public int wDelayTime;
/*    */   
/*    */   public byte byEnablePreset;
/*    */   
/*    */   public int wPreset;
/*    */   
/*    */   public int wBase;
/*    */   
/* 25 */   public byte[] byVoChanNo = new byte[9];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_AUDIO_ACTIVATION_CFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */