/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_CONTROL_PARAM extends NET_DVR_CONTROL
/*    */ {
/*  5 */   public byte[] sDeviceID = new byte[32];
/*    */   
/*    */   public int wChan;
/*    */   
/*    */   public byte byIndex;
/*    */   
/*    */   public byte byRes1;
/*    */   
/*    */   public int dwControlParam;
/*    */   
/* 15 */   public byte[] byRes2 = new byte[32];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_CONTROL_PARAM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */