package com.hikvision.netsdk;

public class NET_DVR_POINT_FRAME
{
  public int xTop;
  public int yTop;
  public int xBottom;
  public int yBottom;
  public int bCounter;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_POINT_FRAME.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */