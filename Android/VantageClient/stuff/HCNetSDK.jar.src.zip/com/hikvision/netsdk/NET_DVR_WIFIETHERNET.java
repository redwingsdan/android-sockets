/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_WIFIETHERNET
/*    */ {
/*  9 */   public byte[] sIpAddress = new byte[16];
/*    */   
/* 11 */   public byte[] sIpMask = new byte[16];
/*    */   
/* 13 */   public byte[] byMACAddr = new byte[6];
/*    */   
/*    */   public int dwEnableDhcp;
/*    */   
/*    */   public int dwAutoDns;
/*    */   
/* 19 */   public byte[] sFirstDns = new byte[16];
/*    */   
/* 21 */   public byte[] sSecondDns = new byte[16];
/*    */   
/* 23 */   public byte[] sGatewayIpAddr = new byte[16];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_WIFIETHERNET.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */