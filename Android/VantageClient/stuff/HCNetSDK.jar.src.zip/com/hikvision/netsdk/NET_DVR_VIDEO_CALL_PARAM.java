/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ public class NET_DVR_VIDEO_CALL_PARAM
/*   */   extends NET_DVR_CONFIG
/*   */ {
/*   */   public int dwCmdType;
/* 7 */   public byte[] byRes = new byte[''];
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_VIDEO_CALL_PARAM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */