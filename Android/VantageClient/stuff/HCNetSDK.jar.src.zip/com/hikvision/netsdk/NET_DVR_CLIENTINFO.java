package com.hikvision.netsdk;

public class NET_DVR_CLIENTINFO
{
  public int lChannel;
  public int lLinkMode;
  public String sMultiCastIP;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_CLIENTINFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */