/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ALARMINFO_V30
/*    */   extends NET_DVR_BASE_ALARM
/*    */ {
/*    */   public int dwAlarmType;
/*    */   
/*    */ 
/*    */   public int dwAlarmInputNumber;
/*    */   
/*    */ 
/* 14 */   public byte[] byAlarmOutputNumber = new byte[96];
/*    */   
/* 16 */   public byte[] byAlarmRelateChannel = new byte[64];
/*    */   
/* 18 */   public byte[] byChannel = new byte[64];
/*    */   
/* 20 */   public byte[] byDiskNumber = new byte[33];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMINFO_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */