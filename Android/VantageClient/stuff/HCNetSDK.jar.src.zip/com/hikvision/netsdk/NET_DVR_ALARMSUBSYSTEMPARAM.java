/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ALARMSUBSYSTEMPARAM
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int wEnterDelay;
/*    */   
/*    */   public int wExitDelay;
/*    */   
/*    */   public byte byHostageReport;
/*    */   
/*    */   public byte bySubsystemEnable;
/*    */   
/*    */   public byte byKeyToneOfArmOrDisarm;
/*    */   
/*    */   public byte byKeyToneOfManualTestReport;
/*    */   
/*    */   public int wDelayTime;
/*    */   
/*    */   public byte byRes1;
/*    */   public byte byPublicAttributeEnable;
/* 23 */   public NET_DVR_JOINT_SUB_SYSTEM struJointSubSystem = new NET_DVR_JOINT_SUB_SYSTEM();
/*    */   
/*    */   public byte byKeyZoneArm;
/*    */   
/*    */   public byte byKeyZoneArmReport;
/*    */   
/*    */   public byte byKeyZoneDisarm;
/*    */   
/*    */   public byte byKeyZoneDisarmReport;
/*    */   
/* 33 */   public byte[] byRes2 = new byte['ɰ'];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMSUBSYSTEMPARAM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */