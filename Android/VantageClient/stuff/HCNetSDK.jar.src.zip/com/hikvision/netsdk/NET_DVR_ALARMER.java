/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_ALARMER
/*    */ {
/*    */   public byte byUserIDValid;
/*    */   
/*    */ 
/*    */   public byte bySerialValid;
/*    */   
/*    */ 
/*    */   public byte byVersionValid;
/*    */   
/*    */   public byte byDeviceNameValid;
/*    */   
/*    */   public byte byMacAddrValid;
/*    */   
/*    */   public byte byLinkPortValid;
/*    */   
/*    */   public byte byDeviceIPValid;
/*    */   
/*    */   public byte bySocketIPValid;
/*    */   
/*    */   public int lUserID;
/*    */   
/* 27 */   public byte[] sSerialNumber = new byte[48];
/*    */   
/*    */   public int dwDeviceVersion;
/*    */   
/* 31 */   public byte[] sDeviceName = new byte[32];
/*    */   
/* 33 */   public byte[] byMacAddr = new byte[6];
/*    */   
/*    */   public short wLinkPort;
/*    */   
/* 37 */   public byte[] sDeviceIP = new byte[''];
/*    */   
/* 39 */   public byte[] sSocketIP = new byte[''];
/*    */   
/*    */   public byte byIpProtocol;
/* 42 */   public byte[] byRes2 = new byte[11];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMER.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */