/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class WPA_WPA2
/*    */ {
/*    */   public byte byEncryptType;
/*    */   
/*    */ 
/*    */   public byte byAuthType;
/*    */   
/*    */ 
/* 13 */   public EAP_TTLS struEapTtls = new EAP_TTLS();
/*    */   
/* 15 */   public EAP_PEAP struEapPeap = new EAP_PEAP();
/*    */   
/* 17 */   public EAP_TLS struEapTls = new EAP_TLS();
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\WPA_WPA2.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */