/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_DEVICECFG
/*    */   extends NET_DVR_CONFIG
/*    */ {
/* 12 */   public byte[] sDVRName = new byte[32];
/*    */   
/*    */ 
/*    */   public int dwDVRID;
/*    */   
/*    */ 
/*    */   public int dwRecycleRecord;
/*    */   
/* 20 */   public byte[] sSerialNumber = new byte[48];
/*    */   public int dwSoftwareVersion;
/*    */   public int dwSoftwareBuildDate;
/*    */   public int dwDSPSoftwareVersion;
/*    */   public int dwDSPSoftwareBuildDate;
/*    */   public int dwPanelVersion;
/*    */   public int dwHardwareVersion;
/*    */   public byte byAlarmInPortNum;
/*    */   public byte byAlarmOutPortNum;
/*    */   public byte byRS232Num;
/*    */   public byte byRS485Num;
/*    */   public byte byNetworkPortNum;
/*    */   public byte byDiskCtrlNum;
/*    */   public byte byDiskNum;
/*    */   public byte byDVRType;
/*    */   public byte byChanNum;
/*    */   public byte byStartChan;
/*    */   public byte byDecordChans;
/*    */   public byte byVGANum;
/*    */   public byte byUSBNum;
/*    */   public byte byAuxoutNum;
/*    */   public byte byAudioNum;
/*    */   public byte byIPChanNum;
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DEVICECFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */