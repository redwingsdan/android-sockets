/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public class NET_DVR_PREVIEW_SWITCH_CFG
/*   */   extends NET_DVR_CONFIG
/*   */ {
/* 9 */   public short[] wSwitchSeq = new short[64];
/*   */   public byte byPreviewNumber;
/*   */   public byte byEnableAudio;
/*   */   public byte bySwitchTime;
/*   */   public byte bySameSource;
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PREVIEW_SWITCH_CFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */