/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_DESC_NODE
/*    */ {
/*    */   public int iValue;
/*    */   
/*    */ 
/* 11 */   public byte[] byDescribe = new byte[32];
/*    */   
/*    */   public int dwFreeSpace;
/*    */   
/* 15 */   public byte[] byRes = new byte[12];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DESC_NODE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */