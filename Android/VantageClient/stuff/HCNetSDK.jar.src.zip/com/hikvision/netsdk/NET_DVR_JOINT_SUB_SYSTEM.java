/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ public class NET_DVR_JOINT_SUB_SYSTEM
/*   */ {
/* 5 */   public NET_DVR_NOAMAL_SUB_SYSTEM struNormalSubSystem = new NET_DVR_NOAMAL_SUB_SYSTEM();
/*   */   
/* 7 */   public NET_DVR_PUBLIC_SUB_SYSTEM struPublicSubSystem = new NET_DVR_PUBLIC_SUB_SYSTEM();
/*   */   
/* 9 */   public byte[] byRes = new byte[20];
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_JOINT_SUB_SYSTEM.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */