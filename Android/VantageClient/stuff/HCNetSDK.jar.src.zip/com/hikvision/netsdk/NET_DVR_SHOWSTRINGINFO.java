/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_SHOWSTRINGINFO
/*    */ {
/*    */   public int wShowString;
/*    */   
/*    */ 
/*    */   public int wStringSize;
/*    */   
/*    */ 
/*    */   public int wShowStringTopLeftX;
/*    */   
/*    */   public int wShowStringTopLeftY;
/*    */   
/* 17 */   public byte[] sString = new byte[44];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SHOWSTRINGINFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */