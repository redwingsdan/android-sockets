/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_COMPRESSION_AUDIO
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public byte byAudioEncType;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/* 15 */   public byte[] byres = new byte[7];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_COMPRESSION_AUDIO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */