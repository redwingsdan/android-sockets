/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_FINDDATA_V30
/*    */ {
/* 10 */   public byte[] sFileName = new byte[100];
/*    */   
/* 12 */   public NET_DVR_TIME struStartTime = new NET_DVR_TIME();
/*    */   
/* 14 */   public NET_DVR_TIME struStopTime = new NET_DVR_TIME();
/*    */   
/*    */   public int dwFileSize;
/*    */   
/* 18 */   public byte[] sCardNum = new byte[32];
/*    */   
/*    */   public byte byLocked;
/*    */   
/*    */   public byte byFileType;
/*    */   
/* 24 */   public byte[] byRes = new byte[2];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_FINDDATA_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */