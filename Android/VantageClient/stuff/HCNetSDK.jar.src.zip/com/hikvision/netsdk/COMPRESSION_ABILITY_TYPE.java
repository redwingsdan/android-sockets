package com.hikvision.netsdk;

public class COMPRESSION_ABILITY_TYPE
{
  public static final int COMPRESSION_STREAM_ABILITY = 0;
  public static final int MAIN_RESOLUTION_ABILITY = 1;
  public static final int SUB_RESOLUTION_ABILITY = 2;
  public static final int EVENT_RESOLUTION_ABILITY = 3;
  public static final int FRAME_ABILITY = 4;
  public static final int BITRATE_TYPE_ABILITY = 5;
  public static final int BITRATE_ABILITY = 6;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\COMPRESSION_ABILITY_TYPE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */