/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_IPC_CALLHELP_ALARMCFG
/*    */ {
/*    */   public byte byAlarmHandle;
/*    */   
/*    */ 
/* 11 */   public NET_DVR_HANDLEEXCEPTION_V30 struAlarmHandleType = new NET_DVR_HANDLEEXCEPTION_V30();
/*    */   
/* 13 */   public byte[] byRelRecordChan = new byte[64];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_IPC_CALLHELP_ALARMCFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */