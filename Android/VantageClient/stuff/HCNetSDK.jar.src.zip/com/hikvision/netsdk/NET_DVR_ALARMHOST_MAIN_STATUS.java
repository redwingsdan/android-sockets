/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_ALARMHOST_MAIN_STATUS extends NET_DVR_CONFIG
/*    */ {
/*  5 */   public byte[] bySetupAlarmStatus = new byte['Ȁ'];
/*    */   
/*  7 */   public byte[] byAlarmInStatus = new byte['Ȁ'];
/*    */   
/*  9 */   public byte[] byAlarmOutStatus = new byte['Ȁ'];
/*    */   
/* 11 */   public byte[] byBypassStatus = new byte['Ȁ'];
/*    */   
/* 13 */   public byte[] bySubSystemGuardStatus = new byte[32];
/*    */   
/* 15 */   public byte[] byAlarmInFaultStatus = new byte['Ȁ'];
/*    */   
/* 17 */   public byte[] byRes = new byte[56];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_ALARMHOST_MAIN_STATUS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */