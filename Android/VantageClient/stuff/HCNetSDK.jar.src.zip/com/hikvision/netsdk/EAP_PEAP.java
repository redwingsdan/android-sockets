/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EAP_PEAP
/*    */ {
/*    */   public byte byEapolVersion;
/*    */   
/*    */ 
/*    */   public byte byAuthType;
/*    */   
/*    */ 
/*    */   public byte byPeapVersion;
/*    */   
/*    */   public byte byPeapLabel;
/*    */   
/* 17 */   public byte[] byAnonyIdentity = new byte[32];
/*    */   
/* 19 */   public byte[] byUserName = new byte[32];
/*    */   
/* 21 */   public byte[] byPassword = new byte[32];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\EAP_PEAP.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */