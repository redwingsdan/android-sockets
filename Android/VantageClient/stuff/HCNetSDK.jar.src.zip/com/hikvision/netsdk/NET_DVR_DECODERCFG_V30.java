/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_DECODERCFG_V30
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int dwBaudRate;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte byDataBit;
/*    */   
/*    */ 
/*    */ 
/*    */ 
/*    */   public byte byStopBit;
/*    */   
/*    */ 
/*    */ 
/*    */   public byte byParity;
/*    */   
/*    */ 
/*    */ 
/*    */   public byte byFlowcontrol;
/*    */   
/*    */ 
/*    */ 
/*    */   public short wDecoderType;
/*    */   
/*    */ 
/*    */ 
/*    */   public short wDecoderAddress;
/*    */   
/*    */ 
/*    */ 
/* 40 */   public byte[] bySetPreset = new byte['Ā'];
/*    */   
/*    */ 
/*    */ 
/* 44 */   public byte[] bySetCruise = new byte['Ā'];
/*    */   
/*    */ 
/*    */ 
/* 48 */   public byte[] bySetTrack = new byte['Ā'];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DECODERCFG_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */