/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_IPADDR
/*    */ {
/* 10 */   public byte[] sIpV4 = new byte[16];
/*    */   
/* 12 */   public byte[] sIpV6 = new byte[''];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_IPADDR.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */