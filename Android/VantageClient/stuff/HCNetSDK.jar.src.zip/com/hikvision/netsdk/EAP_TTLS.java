/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class EAP_TTLS
/*    */ {
/*    */   public byte byEapolVersion;
/*    */   
/*    */ 
/*    */   public byte byAuthType;
/*    */   
/*    */ 
/* 13 */   public byte[] byAnonyIdentity = new byte[32];
/*    */   
/* 15 */   public byte[] byUserName = new byte[32];
/*    */   
/* 17 */   public byte[] byPassword = new byte[32];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\EAP_TTLS.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */