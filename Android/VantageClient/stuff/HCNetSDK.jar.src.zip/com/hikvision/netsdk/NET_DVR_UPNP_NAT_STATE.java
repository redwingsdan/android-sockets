/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_UPNP_NAT_STATE
/*    */ {
/* 11 */   public NET_DVR_UPNP_PORT_STATE[] strUpnpPort = new NET_DVR_UPNP_PORT_STATE[12];
/*    */   
/*    */   public NET_DVR_UPNP_NAT_STATE() {
/* 14 */     for (int i = 0; i < 12; i++)
/*    */     {
/* 16 */       this.strUpnpPort[i] = new NET_DVR_UPNP_PORT_STATE();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_UPNP_NAT_STATE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */