/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_CHANNELSTATE_V30
/*    */ {
/*    */   public byte byRecordStatic;
/*    */   
/*    */ 
/*    */   public byte bySignalStatic;
/*    */   
/*    */ 
/*    */   public byte byHardwareStatic;
/*    */   
/*    */   public int dwBitRate;
/*    */   
/*    */   public int dwLinkNum;
/*    */   
/* 19 */   public NET_DVR_IPADDR[] struClientIP = new NET_DVR_IPADDR[6];
/*    */   
/*    */   public int dwIPLinkNum;
/*    */   public byte byExceedMaxLink;
/*    */   
/*    */   public NET_DVR_CHANNELSTATE_V30()
/*    */   {
/* 26 */     for (int i = 0; i < 6; i++) {
/* 27 */       this.struClientIP[i] = new NET_DVR_IPADDR();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_CHANNELSTATE_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */