/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ public class NET_DVR_SINGLE_CHANNEL_LINKAGE_CFG
/*    */ {
/*    */   public byte byAddressType;
/*    */   
/*    */   public byte byRes1;
/*    */   
/*    */   public int wPort;
/* 11 */   public byte[] szDomain = new byte[64];
/*    */   
/* 13 */   public byte[] byRes2 = new byte[80];
/*    */   
/* 15 */   public NET_DVR_IPADDR struIp = new NET_DVR_IPADDR();
/*    */   
/* 17 */   public byte[] sUserName = new byte[32];
/*    */   
/* 19 */   public byte[] sPassword = new byte[16];
/*    */   
/*    */   public int dwChannel;
/*    */   
/* 23 */   public byte[] byRes3 = new byte[64];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SINGLE_CHANNEL_LINKAGE_CFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */