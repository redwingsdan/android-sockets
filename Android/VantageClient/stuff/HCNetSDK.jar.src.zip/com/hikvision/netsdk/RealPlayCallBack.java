package com.hikvision.netsdk;

public abstract interface RealPlayCallBack
{
  public abstract void fRealDataCallBack(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\RealPlayCallBack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */