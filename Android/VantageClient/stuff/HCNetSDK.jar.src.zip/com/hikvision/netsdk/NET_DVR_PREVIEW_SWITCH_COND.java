package com.hikvision.netsdk;

public class NET_DVR_PREVIEW_SWITCH_COND
  extends NET_DVR_CONDITION
{
  public byte byGroup;
  public byte byVideoOutType;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PREVIEW_SWITCH_COND.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */