/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_SEARCH_EVENT_RET
/*    */ {
/*    */   public short wMajorType;
/*    */   
/*    */ 
/*    */   public short wMinorType;
/*    */   
/*    */ 
/* 13 */   public NET_DVR_TIME struStartTime = new NET_DVR_TIME();
/*    */   
/* 15 */   public NET_DVR_TIME struEndTime = new NET_DVR_TIME();
/*    */   public int dwAlarmInNo;
/*    */   public int dwMotDetNo;
/*    */   public int dwBehaviorChanNo;
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SEARCH_EVENT_RET.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */