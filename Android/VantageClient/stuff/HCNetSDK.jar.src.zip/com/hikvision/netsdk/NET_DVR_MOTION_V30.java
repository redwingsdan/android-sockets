/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_MOTION_V30
/*    */ {
/* 10 */   public byte[][] byMotionScope = new byte[64][96];
/*    */   
/*    */   public byte byMotionSensitive;
/*    */   
/*    */   public byte byEnableHandleMotion;
/*    */   
/* 16 */   public NET_DVR_HANDLEEXCEPTION_V30 struMotionHandleType = new NET_DVR_HANDLEEXCEPTION_V30();
/*    */   
/* 18 */   public NET_DVR_SCHEDTIME[][] struAlarmTime = new NET_DVR_SCHEDTIME[7][8];
/*    */   
/* 20 */   public byte[] byRelRecordChan = new byte[64];
/*    */   
/*    */   public NET_DVR_MOTION_V30() {
/* 23 */     for (int i = 0; i < 7; i++)
/*    */     {
/* 25 */       for (int j = 0; j < 8; j++)
/*    */       {
/* 27 */         this.struAlarmTime[i][j] = new NET_DVR_SCHEDTIME();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_MOTION_V30.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */