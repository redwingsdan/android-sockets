/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ public class NET_DVR_SUBSYSTEM_PARAM_EX extends NET_DVR_CONFIG
/*    */ {
/*  5 */   public NET_DVR_SCHEDTIME[][] struAlarmTime = new NET_DVR_SCHEDTIME[7][8];
/*    */   
/*    */   public byte byAlarmInAdvance;
/*    */   
/*  9 */   public byte[] byRes1 = new byte[3];
/*    */   
/* 11 */   public byte[] byJointAlarmIn = new byte[64];
/*    */   
/* 13 */   public byte[] byJointKeyboard = new byte[8];
/*    */   
/* 15 */   public byte[] byJointOpetaterUser = new byte[32];
/*    */   
/* 17 */   public byte[] byRes2 = new byte['Ȁ'];
/*    */   
/*    */   public NET_DVR_SUBSYSTEM_PARAM_EX()
/*    */   {
/* 21 */     for (int i = 0; i < 7; i++)
/*    */     {
/* 23 */       for (int j = 0; j < 8; j++)
/*    */       {
/* 25 */         this.struAlarmTime[i][j] = new NET_DVR_SCHEDTIME();
/*    */       }
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_SUBSYSTEM_PARAM_EX.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */