/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_IPPARACFG_V40
/*    */   extends NET_DVR_CONFIG
/*    */ {
/*    */   public int dwGroupNum;
/*    */   
/*    */ 
/*    */   public int dwAChanNum;
/*    */   
/*    */ 
/*    */   public int dwDChanNum;
/*    */   
/*    */   public int dwStartDChan;
/*    */   
/* 18 */   public byte[] byAnalogChanEnable = new byte[64];
/*    */   
/* 20 */   public NET_DVR_IPDEVINFO_V31[] struIPDevInfo = new NET_DVR_IPDEVINFO_V31[64];
/*    */   
/* 22 */   public NET_DVR_IPCHANINFO[] struIPChanInfo = new NET_DVR_IPCHANINFO[64];
/*    */   
/*    */   public NET_DVR_IPPARACFG_V40()
/*    */   {
/* 26 */     for (int i = 0; i < 64; i++)
/*    */     {
/* 28 */       this.struIPDevInfo[i] = new NET_DVR_IPDEVINFO_V31();
/*    */     }
/*    */     
/* 31 */     for (int i = 0; i < 64; i++)
/*    */     {
/* 33 */       this.struIPChanInfo[i] = new NET_DVR_IPCHANINFO();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_IPPARACFG_V40.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */