package com.hikvision.netsdk;

public class MAIN_EVENT_TYPE
{
  public static final int EVENT_MOT_DET = 0;
  public static final int EVENT_ALARM_IN = 1;
  public static final int EVENT_VCA_BEHAVIOR = 2;
  public static final int EVENT_VCA_DETECTION = 4;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\MAIN_EVENT_TYPE.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */