package com.hikvision.netsdk;

public class PTZTrackCmd
{
  public static final int STA_MEM_CRUISE = 34;
  public static final int STO_MEM_CRUISE = 35;
  public static final int RUN_CRUISE = 36;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\PTZTrackCmd.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */