package com.hikvision.netsdk;

public class NET_DVR_DEVICE_CONFIG_COMMAND
{
  public static final int NET_DVR_GET_PREVIEW_SWITCH_CFG = 6166;
  public static final int NET_DVR_SET_PREVIEW_SWITCH_CFG = 6167;
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_DEVICE_CONFIG_COMMAND.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */