/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_IPALARMOUTINFO
/*    */ {
/*    */   public byte byIPID;
/*    */   
/*    */ 
/*    */   public byte byAlarmOut;
/*    */   
/*    */ 
/* 13 */   public byte[] byRes = new byte[18];
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_IPALARMOUTINFO.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */