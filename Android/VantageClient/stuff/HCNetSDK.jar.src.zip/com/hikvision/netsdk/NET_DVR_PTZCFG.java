/*    */ package com.hikvision.netsdk;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class NET_DVR_PTZCFG
/*    */ {
/*    */   public int dwPtzNum;
/*    */   
/*    */ 
/* 11 */   public NET_DVR_PTZ_PROTOCOL[] struPtz = new NET_DVR_PTZ_PROTOCOL['È'];
/*    */   
/*    */   public NET_DVR_PTZCFG() {
/* 14 */     for (int i = 0; i < 200; i++) {
/* 15 */       this.struPtz[i] = new NET_DVR_PTZ_PROTOCOL();
/*    */     }
/*    */   }
/*    */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_PTZCFG.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */