package com.hikvision.netsdk;

public abstract interface PlaybackCallBack
{
  public abstract void fPlayDataCallBack(int paramInt1, int paramInt2, byte[] paramArrayOfByte, int paramInt3);
}


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\PlaybackCallBack.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */