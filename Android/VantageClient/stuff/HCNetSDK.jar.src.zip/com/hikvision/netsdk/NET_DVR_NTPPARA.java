/*   */ package com.hikvision.netsdk;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public class NET_DVR_NTPPARA
/*   */   extends NET_DVR_CONFIG
/*   */ {
/* 9 */   public byte[] sNTPServer = new byte[64];
/*   */   public short wInterval;
/*   */   public byte byEnableNTP;
/*   */   public char cTimeDifferenceH;
/*   */   public char cTimeDifferenceM;
/*   */   public short wNtpPort;
/*   */ }


/* Location:              C:\Users\jburmeister\Desktop\SimpleDemo\HCNetSDK\HCNetSDK.jar!\com\hikvision\netsdk\NET_DVR_NTPPARA.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */